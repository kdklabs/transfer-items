import os
from pprint import pprint

os.environ["CURL_CA_BUNDLE"] = ""
import os
import json
from transformers import AutoTokenizer, AutoModelForTokenClassification
from parsers.word_parser.VisionDocumentParser import TextDocumentParser


class TestDocumentParsing:
    def __init__(self, path):
        self.model_id = "pierreguillou/lilt-xlm-roberta-base-finetuned-with-DocLayNet-base-at-linelevel-ml384"
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        self.model = AutoModelForTokenClassification.from_pretrained(self.model_id)
        self.path = path
        self.file_name = os.path.splitext(os.path.basename(path))[0]

    def parse(self):
        parser = TextDocumentParser(self.model, self.tokenizer)
        doc_data = parser.parse(self.path, "document", None)
        return doc_data

    def dump_to_json(self, doc_data):
        with open(self.file_name + ".json", "w") as out_file:
            json.dump(doc_data, out_file, indent=6)


# test_doc = TestDocumentParsing("..\\resources\\sample.docx")
# doc_data = test_doc.parse()
# test_doc.dump_to_json(doc_data)
# pprint(doc_data)