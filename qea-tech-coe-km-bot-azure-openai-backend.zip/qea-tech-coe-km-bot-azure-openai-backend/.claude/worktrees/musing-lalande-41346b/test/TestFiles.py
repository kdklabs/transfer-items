import os

from typing import Optional
from docx import Document

# from mediahandlers.MediaTranscribe import MediaTranscribe
from parsers.PPTParser import PPTParser
from parsers.MarkdownParser import parsed_markdown_text_metadata
# from parsers.PDFParser import pdf_parser
from parsers.WordParser import WordParser

from test.TestDocumentParsing import TestDocumentParsing
from CONSTANTS import *
from CONSTANTS import file_extension_map
from utilities.utils import get_current_time, unique_id_generator, reformat_parser_output
from pprint import pprint
import whisper


class VectorDb:
    def __init__(self, setup_utilities):

        # self.db_type = setup_utilities.load_config_file().get('db_type')
        # self.vectordb = ChromaDbClient(db_path=dbpath)
        self.vectordb = setup_utilities.setup_vector_database_client()
        self.word_parser_obj = setup_utilities.setup_word_parser()
        self.ppt_parser_obj = setup_utilities.setup_ppt_parser()
        # define the collection name and load them to config
        self.markdown_files = DOCUMENT_DATA
        self.conversation_summary = CONVERSATION_SUMMARY
        self.cache_question_answer = CACHED_QUESTION_ANSWER

        # logger.info("ChromaDb Connection established")
        print("ChromaDb Connection established")

    async def create_collection_on_start(self):
        markdown_collection = await self.vectordb._get_create_collection(self.markdown_files)
        conversation_summary = await self.vectordb._get_create_collection(self.conversation_summary)
        cache_question_answer = await self.vectordb._get_create_collection(self.cache_question_answer)

        return markdown_collection, conversation_summary, cache_question_answer

    async def get_retriever(self):
        retriever = await self.vectordb.chroma_as_retriever(self.markdown_files)
        return retriever

    async def add_markdown_documents(self, list_of_file_path: list[str]):

        add_status = None
        try:

            # Process each Markdown file

            print("list_of_file_path:", list_of_file_path)
            for file_path in list_of_file_path:

                file_extension = os.path.splitext(file_path)[1][1:]
                file_type = file_extension_map.get(file_extension)

                if file_extension in file_extension_map:
                    if file_type == "markdown":
                        unique_ids, page_content_list, metadata_list = parsed_markdown_text_metadata(file_path)
                        add_status = await self.vectordb.add_to_vector_db(self.markdown_files,
                                                                          documents=page_content_list,
                                                                          document_ids=unique_ids,
                                                                          document_metadata=metadata_list)
                        print(f"File {file_path}  parsing completed")

                    elif file_type == "document" or file_type == "pdf":

                        content = self.word_parser_obj.word_parser(file_path)
                        unique_ids, page_content_list, metadata_list = reformat_parser_output(content)
                        add_status = await self.vectordb.add_to_vector_db(self.markdown_files,
                                                                          documents=page_content_list,
                                                                          document_ids=unique_ids,
                                                                          document_metadata=metadata_list)
                        print(f"File {file_path}  parsing completed")

                    elif file_type == "presentation":
                        unique_ids, page_content_list, metadata_list = reformat_parser_output(self.ppt_parser_obj.parse(
                            document_path=file_path
                        ))
                        add_status = await self.vectordb.add_to_vector_db(self.markdown_files,
                                                                          documents=page_content_list,
                                                                          document_ids=unique_ids,
                                                                          document_metadata=metadata_list)

                    elif file_type == 'video':
                        file_object = {}
                        whisper_models = os.path.join(os.environ['km_azure_home'], 'Model', 'whisper')
                        media_transcribe_model = whisper.load_model('small.en', download_root=whisper_models)
                        media_parser = MediaTranscribe(media_transcribe_model)
                        file_object.update(
                            file_name=os.path.basename(file_path),
                            file_path=file_path,
                            type=file_extension
                        )
                        parser_output = await media_parser.parse(file_path, file_object=file_object)
                        unique_ids, page_content_list, metadata_list = reformat_parser_output(parser_output)
                        add_status = await self.vectordb.add_to_vector_db(self.markdown_files,
                                                                          documents=page_content_list,
                                                                          document_ids=unique_ids,
                                                                          document_metadata=metadata_list)


                # if file_path.endswith('.md'):
                #     unique_ids, page_content_list, metadata_list = parsed_markdown_text_metadata(file_path)
                #     add_status = await self.vectordb.add_to_vector_db(self.markdown_files,
                #                                                       documents=page_content_list,
                #                                                       document_ids=unique_ids,
                #                                                       document_metadata=metadata_list)
                #     print(f"File {file_path}  parsing completed")
                #
                # elif file_path.endswith('.docx') or file_path.endswith('.doc') or file_path.endswith('.pdf'):
                #
                #     content = self.word_parser_obj.word_parser(file_path)
                #     unique_ids, page_content_list, metadata_list = reformat_parser_output(content)
                #     add_status = await self.vectordb.add_to_vector_db(self.markdown_files,
                #                                                       documents=page_content_list,
                #                                                       document_ids=unique_ids,
                #                                                       document_metadata=metadata_list)
                #     print(f"File {file_path}  parsing completed")
                #
                # elif file_path.endswith('.pptx'):
                #     unique_ids, page_content_list, metadata_list = reformat_parser_output(self.ppt_parser_obj.parse(
                #         document_path=file_path
                #     ))
                #     add_status = await self.vectordb.add_to_vector_db(self.markdown_files,
                #                                                       documents=page_content_list,
                #                                                       document_ids=unique_ids,
                #                                                       document_metadata=metadata_list)
                #
                # elif file_extension in file_extension_map and file_type == 'video':
                #
                #     pass

                else:
                    print(f"File {file_path} not supported")

            return add_status


        except Exception as e:
            print(f"An error occurred in add_markdown_documents: {str(e)} filepath:{file_path}")

    async def check_if_file_exist(self, file_list):
        """
        :param file_list:
        :return:
        """
        print(file_list)
        for files in file_list:
            get_all_data_from_vectordb = await self.vectordb.fetch_all_data(self.markdown_files,
                                                                            filter_condition={"file_name": files})

            print(get_all_data_from_vectordb)
            if get_all_data_from_vectordb:
                try:
                    delete_ids = get_all_data_from_vectordb['ids']

                    await self.vectordb.delete_data_vectordb(self.markdown_files, delete_ids)
                    return True

                except Exception as e:
                    print(f"Error caught while fetching all cached questions {e}")
                    # logger.error(f"Error caught while fetching all cached questions {e}")
                    return False

    async def fetch_data_by_filename(self, file_name: str):
        try:

            get_all_data_from_vectordb = await self.vectordb.fetch_all_data(self.markdown_files,
                                                                            filter_condition={"file_name": file_name})
            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None

        except Exception as e:
            print(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def fetch_all_markdown_data(self):
        try:
            formatted_data_dict = []
            get_all_data_from_vectordb = await self.vectordb.fetch_all_data(self.markdown_files, )
            print(get_all_data_from_vectordb)
            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None
        except Exception as e:
            print(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def query_document_user_question(self, user_query: str, threshold: float, tolerance: float,
                                           no_of_results: Optional[int] = 3,
                                           filter_version: Optional[str] = None):

        # matching_question_status, matching_question_id, matching_question = "","",""
        if not user_query:
            raise ValueError("Empty User Query")

        try:
            if filter_version:
                user_query_result, _ = await self.vectordb.find_similar_doc(
                    self.markdown_files,
                    user_query=[user_query],
                    metadata_values=['file_path', 'file_name'],
                    no_of_results=no_of_results,
                    return_doc=True,
                    skip_metadata_verification=True,
                    threshold=threshold,

                    tolerance=tolerance,
                    filter_condition={"release_version": filter_version}
                )
                if user_query_result is None:
                    user_query_result, _ = await self.vectordb.find_similar_doc(
                        self.markdown_files,
                        user_query=[user_query],
                        return_doc=True,
                        metadata_values=['file_path', 'file_name'],
                        skip_metadata_verification=True,
                        threshold=threshold,
                        tolerance=tolerance,
                        no_of_results=no_of_results)
            else:

                user_query_result, _ = await self.vectordb.find_similar_doc(
                    self.markdown_files,
                    user_query=[user_query],
                    return_doc=True,
                    metadata_values=['file_path', 'file_name'],
                    skip_metadata_verification=True,
                    threshold=threshold,
                    tolerance=tolerance,
                    no_of_results=no_of_results)

            # print(f"user_query_result: {user_query_result}")
            return user_query_result

        except IndexError as e:
            # logger.error(f"Error caught while querying question from cache  {e}")
            print(f"Error caught while querying question from cache  {e}")
            return None

    async def create_update_user_chat_history(self, user_host_ip: str, chat_summary: str, user_bot_conversation: str):

        try:

            user_query_result = await self.vectordb.fetch_all_data(
                collection_name=self.conversation_summary,
                #no_of_results_returned=1,
                filter_condition={"user_ip": user_host_ip}

            )
            print("conversation_history", user_query_result)

            if len(user_query_result) != 0:
                user_bot_conversation_history = user_query_result[0]['metadata']['conversation_history']

                if user_bot_conversation_history:
                    user_bot_conversation_list = user_bot_conversation_history.split("<break>")
                    if len(user_bot_conversation_list) == 3:
                        user_bot_conversation_list.pop(0)
                        user_bot_conversation_list.append(user_bot_conversation)
                        user_bot_conversation_history = "<break>".join(user_bot_conversation_list)
                    else:
                        user_bot_conversation_list.append(user_bot_conversation)
                        user_bot_conversation_history = "<break>".join(user_bot_conversation_list)

                previous_chat_history = [chat_summary]

                metadata_list = [{"conversation_history": user_bot_conversation_history,
                                  "history_update": str(get_current_time())}]

                update_status = await self.vectordb.update_data_vectordb(
                    collection_name=self.conversation_summary,
                    document_ids=[user_query_result[0]['id']],
                    documents=previous_chat_history,
                    document_metadata=metadata_list
                )
                return update_status

            else:

                document_id = [unique_id_generator()]
                previous_chat_history = [chat_summary]
                # user_bot_conversation_list = [user_bot_conversation]

                metadata_list = [
                    {"user_ip": user_host_ip, "conversation_history": user_bot_conversation + "<break>",
                     "history_update": str(get_current_time())}]

                add_status = await self.vectordb.add_to_vector_db(
                    self.conversation_summary,
                    documents=previous_chat_history,
                    document_ids=document_id,
                    document_metadata=metadata_list
                )
                return add_status

        except IndexError as e:
            # logger.error(f"Error caught while querying question from cache  {e}")
            print(f"Error caught while update conversation summary {e}")
            return None

    async def fetch_chat_history(self, user_host_ip: str):

        user_query_result = await self.vectordb.get_data_with_id(collection_name=self.conversation_summary,
                                                                 document_ids=[str(user_host_ip)], )

        print("user_query_result : ", user_query_result)

        if len(user_query_result) != 0:
            user_bot_conversation_history = user_query_result[0]['metadata']['conversation_history']
            if user_bot_conversation_history:
                user_bot_conversation_list = user_bot_conversation_history.split("<break>")
                chat_history = user_query_result[0]['document']
                user_bot_conversation_list = [value for value in user_bot_conversation_list if
                                              value is not None and value != "" and value != []]
                return chat_history, user_bot_conversation_list
        else:
            return None, None

        #     last_updated_time = user_query_result['metadatas'][0]['history_update']
        #     user_bot_conversation_list = user_query_result['metadatas'][0]['conversation_history']
        #
        #     if calculate_time_difference(last_updated_time) > 20:
        #         chat_history = None
        #         user_bot_conversation_list = []
        #
        #     else:
        #         chat_history = user_query_result['documents'][0]
        #
        #     return chat_history,user_bot_conversation_list
        # else:
        #     return None

    async def fetch_all_conversation_data(self):

        try:
            get_all_data_from_vectordb = await self.vectordb.fetch_all_data(self.conversation_summary)
            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None

        except Exception as e:
            print(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def delete_conversation_data(self, ids: str):
        try:
            delete_ids = [ids]
            get_all_data_from_vectordb = await self.vectordb.delete_data_vectordb(self.conversation_summary, delete_ids)
            return True

        except Exception as e:
            print(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return False

    async def store_question_in_cache(self, question_uuid, question):
        # storing question and the id:of that question in app db
        question_id_list = [str(question_uuid)]
        question_list = [question]
        question_metadata_list = [{'question_match_app_db_id': question_uuid}]

        cache_status = await self.vectordb.add_to_vector_db(self.cache_question_answer,
                                                            documents=question_list,
                                                            document_ids=question_id_list,
                                                            document_metadata=question_metadata_list)

        return cache_status

    async def fetch_cached_question(self, question):
        retrived_question = await self.vectordb.find_similar_doc(collection_name=self.cache_question_answer,
                                                                 user_query=[question],
                                                                 metadata_values=[
                                                                     'question_match_app_db_id'],
                                                                 skip_metadata_verification=True,
                                                                 return_doc=True,
                                                                 no_of_results=1,
                                                                 threshold=0.99,
                                                                 tolerance=0.05
                                                                 )

        # retrived_question = await self.vectordb.find_similar_doc_with_filter(collection_name=self.cache_question_answer,
        #                                                                      user_query=[question],
        #                                                                      metadata_values=[
        #                                                                          'question_match_app_db_id'],
        #                                                                      skip_metadata_verification=False,
        #                                                                      return_doc=True,
        #                                                                      no_of_results=1,
        #                                                                      threshold=0.99,
        #                                                                      tolerance=0.05
        #                                                                      )

        if retrived_question[0] :
            print("retrived_question", retrived_question)
            print("retrived_question", retrived_question[0][0]['metadata']['question_match_app_db_id'])
            # [{'document': 'What is postman?', 'question_match_app_db_id': "['0b486652-7f76-43fe-ba87-1231b9bb16cb']"}]\
            retrived_id = retrived_question[0][0]['metadata']['question_match_app_db_id']
            # print(list)
            # print(type(retrived_question[0][0]['question_match_app_db_id']))
            return retrived_id

    async def fetch_all_cached_question(self):

        try:
            get_all_data_from_vectordb = await self.vectordb.fetch_all_data(self.cache_question_answer)
            print(get_all_data_from_vectordb)
            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None
        except Exception as e:
            print(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def delete_cache_question(self, ids: str):
        try:
            delete_ids = [ids]
            get_all_data_from_vectordb = await self.vectordb.delete_data_vectordb(self.cache_question_answer,
                                                                                  delete_ids)
            return True

        except Exception as e:
            print(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return False

    async def delete_cache_collection(self):
        delete_cache_status = await self.vectordb.drop_collection(self.cache_question_answer)
        return delete_cache_status

    async def delete_source_data_collection(self):
        delete_source_collection_status = await self.vectordb.drop_collection(self.markdown_files)
        return delete_source_collection_status

    async def delete_conversation_summary_collection(self):
        delete_conversation_summary_status = await self.vectordb.drop_collection(self.conversation_summary)
        return delete_conversation_summary_status