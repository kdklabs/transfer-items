import requests
import json


def send_requests_and_capture_responses(api_url, string_list):
    responses = []

    for string_data in string_list:
        payload = {'msg': string_data}  # Modify this according to the API's requirements
        response = requests.post(api_url, json=payload)
        print(string_data)
        if response.status_code == 200:
            response_json = response.json()
            print(response_json)
            responses.append({'question': string_data, 'response': response_json})
        else:
            responses.append({'question': string_data, 'error': f'Status Code: {response.status_code}'})
        print("\n\n")
    return responses


def write_responses_to_file(responses, output_file):
    with open(output_file, 'w') as file:
        for item in responses:
            file.write(f"Question: {item['question']}\n")
            if 'response' in item:
                file.write(f"Response: {json.dumps(item['response'], indent=2)}\n")
            elif 'error' in item:
                file.write(f"Error: {item['error']}\n")
            file.write("\n")


if __name__ == "__main__":
    # Replace with the API endpoint URL
    api_url = 'http://127.0.0.1:8080/getqueryresponse'

    # Example list of strings
    string_list = [
    ]

    # Send requests and capture responses
    responses = send_requests_and_capture_responses(api_url, string_list)

    # Write responses to a text file
    output_file = 'api_responses_1.txt'
    write_responses_to_file(responses, output_file)

    print(f"Responses written to {output_file}")












