import os

import git
from git import Repo

from utilities.StartupUtilities import startup_utilities
from utilities.AppLogger import global_logger

logger = global_logger

class Github:
    def __init__(self, repo_name,repo_owner_username,repo_download_path):
        self.github_config = startup_utilities.get_github_config()

        self.github_username = self.github_config['user_name']
        self.github_user_token = self.github_config['user_token']
        self.repo_name = repo_name
        self.repo_owner_username = repo_owner_username
        self.repository_url = f"https://{self.github_username}:{self.github_user_token}@github.com/{self.repo_owner_username}/{self.repo_name}.git"
        self.repo_download_path = repo_download_path


    def _check_local_folder_has_same_repo(self):
        try:
            # Check if the local folder is a valid Git repository
            local_repo = git.Repo(self.repo_download_path)

            # Get the URL of the remote named 'origin'
            remote_url = local_repo.remotes.origin.url

            # Compare the URL of the local repository with the provided URL
            if remote_url == self.repository_url:
                logger.success(f"The local folder is a Git repository with the same URL: {self.repository_url}")
                return True
            else:
                logger.error(f"The local folder is a Git repository, but with a different URL: {remote_url}")
                return False
        except git.exc.InvalidGitRepositoryError:
            logger.error("The local folder is not a Git repository.")
            return False

    @staticmethod
    def is_git_repository(folder_path):
        try:
            git.Repo(folder_path)
            return True
        except git.InvalidGitRepositoryError:
            return False

    def clone_repository(self):
        file_downloaded = False
        try:

            if os.path.exists(self.repo_download_path):
                if self._check_local_folder_has_same_repo():
                    file_downloaded = True

                elif self.is_git_repository(self.repo_download_path) is False:
                    Repo.clone_from(self.repository_url, self.repo_download_path)
                    file_downloaded = True
                    logger.success(f"Successfully cloned repo  at {self.repo_download_path} ")

                else:
                    file_downloaded = False
            if not os.path.exists(self.repo_download_path):
                # Clone the repository if it doesn't exist locally
                Repo.clone_from(self.repository_url, self.repo_download_path)
                file_downloaded = True
                logger.success(f"Successfully cloned repo  at {self.repo_download_path} ")

            return file_downloaded, self.repo_download_path
        except git.exc.InvalidGitRepositoryError:
            logger.error("The local folder is not a Git repository.")
            return False, None

    def pull_repository(self):
        """
        Todo:
            - logic when folder exists and is not a github dir how to deal with it
            -
        :return:
        """
        file_updated = False

        list_of_updated_files = []

        if os.path.exists(self.repo_download_path):
            if self._check_local_folder_has_same_repo():
                repo = Repo(self.repo_download_path)
                # Store the current commit before the pull
                current_commit = repo.head.commit
                # Perform the git pull
                repo.remotes.origin.pull()
                # Get the commit after the pull
                new_commit = repo.head.commit
                # Compare the file changes between the two commits
                diff = new_commit.diff(current_commit)
                # List the updated files
                list_of_updated_files = [os.path.join(self.repo_download_path, item.a_path) for item in diff]

                if list_of_updated_files:
                    file_updated = True
                    logger.info("Updated files:")
                    for file in list_of_updated_files:
                        logger.info(file)
                else:
                    logger.info("No files were updated.")
        else:
            file_updated = False

        return file_updated, list_of_updated_files
