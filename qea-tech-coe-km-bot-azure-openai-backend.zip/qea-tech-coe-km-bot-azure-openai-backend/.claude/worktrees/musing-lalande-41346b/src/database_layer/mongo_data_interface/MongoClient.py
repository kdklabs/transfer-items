import motor.motor_asyncio
from bson import ObjectId
from utilities.AppLogger import global_logger
import os

logger = global_logger


class MongoDbConnector(object):
    def __init__(self, db_parameters: dict):
        try:
            db_name = db_parameters.get("db_name")
            db_username = db_parameters.get("db_username")
            db_password = db_parameters.get("db_password")
            db_host = db_parameters.get("db_host")
            db_port = db_parameters.get("db_port")

            uri = f"mongodb://{db_username}:{db_password}@{db_host}:{db_port}/{db_name}"

            # Create a new client and connect to the server
            self.client = motor.motor_asyncio.AsyncIOMotorClient(uri)
            self.mongo_client = self.client[db_name]
            logger.info("MongoDB connection initialized.")
        except Exception as e:
            logger.error(f"Error initializing MongoDB connection: {e}")
            raise e

    async def check_connection(self):
        try:
            # Ping the MongoDB server
            dbs = await self.client.list_database_names()
            logger.info("MongoDB server is responsive!")
            return dbs
        except Exception as e:
            logger.error(f"Error connecting to MongoDB: {e}")
            raise e

    async def add_single_document_to_db(self, collection: str, document: dict) -> (bool, int):
        try:
            insert_document = await self.mongo_client.get_collection(collection).insert_one(document)
            logger.info(f"Document inserted successfully in collection: {collection}")
            return insert_document.acknowledged, insert_document.inserted_id
        except Exception as e:
            logger.error(f"Error inserting document in collection: {e}")
            raise e

    async def add_multiple_document_to_db(self, collection: str, multiple_document: list[dict]) -> (bool, list[int]):
        try:
            insert_document = await self.mongo_client.get_collection(collection).insert_many(multiple_document)
            logger.info(f"Multiple documents inserted successfully in collection: {collection}")
            return insert_document.acknowledged, insert_document.inserted_ids
        except Exception as e:
            logger.error(f"Error inserting multiple documents in collection: {e}")
            raise e

    async def query_document_by_id(self, collection: str, id_value: str):
        try:
            query_document = await self.mongo_client.get_collection(collection).find_one({"_id": ObjectId(id_value)})
            if query_document and '_id' in query_document:
                query_document['_id'] = str(query_document['_id'])
            logger.info(f"Document queried by id successfully in collection: {collection}")
            return query_document
        except Exception as e:
            logger.error(f"Error querying document by id in collection: {e}")
            raise e

    async def query_single_document(self, collection: str, parameter_name: str, parameter_value: str):
        try:
            if parameter_name == "_id":
                parameter_value = ObjectId(parameter_value)
            query_document = await self.mongo_client.get_collection(collection).find_one(
                {f"{parameter_name}": parameter_value})
            if query_document and '_id' in query_document:
                query_document['_id'] = str(query_document['_id'])
            logger.info(f"Single document queried successfully in collection: {collection}")
            return query_document
        except Exception as e:
            logger.error(f"Error querying single document in collection: {e}")
            raise e

    async def query_multiple_document(self, collection: str, condition: dict):
        try:
            query_documents = await self.mongo_client.get_collection(collection).find(condition).to_list(None)
            for document in query_documents:
                document["_id"] = str(document["_id"])
            logger.info(f"Multiple documents queried successfully in collection: {collection}")
            return query_documents
        except Exception as e:
            logger.error(f"Error querying multiple documents in collection: {e}")
            raise e

    async def get_all_collection_document(self, collection: str) -> list[dict]:
        try:
            all_query_document = await self.mongo_client.get_collection(collection).find().to_list(length=None)
            if len(all_query_document) != 0:
                for document in all_query_document:
                    if '_id' in document:
                        document['_id'] = str(document['_id'])
            logger.info(f"All documents retrieved successfully from collection: {collection}")
            return all_query_document
        except Exception as e:
            logger.error(f"Error retrieving all documents from collection: {e}")
            raise e

    async def update_one_document(self, collection: str, filter_criteria: dict, update_operation: dict) -> (
            int, int, str):
        try:
            if filter_criteria.get("_id"):
                filter_criteria = {"_id": ObjectId(filter_criteria['_id'])}
            update_result = await self.mongo_client.get_collection(collection).update_one(
                filter_criteria,
                {"$set": update_operation}
            )
            # Access the result parameters
            matched_count = update_result.matched_count
            modified_count = update_result.modified_count
            upsert_id = str(update_result.upserted_id)
            logger.info(f"One document updated successfully in collection: {collection}")
            return matched_count, modified_count, upsert_id
        except Exception as e:
            logger.error(f"Error updating one document in collection: {e}")
            raise e

    async def delete_document(self, collection: str, delete_condition: dict):
        try:
            if '_id' in delete_condition.keys():
                delete_condition["_id"] = ObjectId(delete_condition["_id"])
            result_delete = await self.mongo_client.get_collection(collection).delete_one(delete_condition)
            logger.info(f"Document deleted successfully in collection: {collection}")
            return result_delete.deleted_count
        except Exception as e:
            logger.error(f"Error deleting document in collection: {e}")
            raise e

    async def delete_all_document(self, collection: str):
        try:
            # Check if there are any documents in the collection
            document_count = await self.mongo_client.get_collection(collection).count_documents({})
            if document_count == 0:
                logger.info(f"Collection already empty {collection}")
                return True
            result_delete = await self.mongo_client.get_collection(collection).delete_many({})
            logger.info(f"All documents deleted successfully in collection: {collection}")
            return result_delete.deleted_count
        except Exception as e:
            logger.error(f"Error deleting all documents in collection: {e}")
            raise e

    async def count_documents_in_collection(self, collection: str, filter_condition: dict = {}):
        try:
            count = await self.mongo_client.get_collection(collection).count_documents(filter_condition)
            logger.info(f"Counted documents in collection: {collection}")
            return count
        except Exception as e:
            logger.error(f"Error counting documents in collection: {e}")
            raise e

    async def aggregate_documents(self, collection: str, pipeline: list):
        try:
            result = await self.mongo_client.get_collection(collection).aggregate(pipeline).to_list(length=None)
            logger.info(f"Aggregated documents in collection: {collection}")
            return result
        except Exception as e:
            logger.error(f"Error aggregating documents in collection: {e}")
            raise e

    async def create_index(self, collection: str, keys: dict, options: dict = {}):
        try:
            result = await self.mongo_client.get_collection(collection).create_index(keys, **options)
            logger.info(f"Created index in collection: {collection}")
            return result
        except Exception as e:
            logger.error(f"Error creating index in collection: {e}")
            raise e

    async def drop_index(self, collection: str, index_name: str):
        try:
            await self.mongo_client.get_collection(collection).drop_index(index_name)
            logger.info(f"Dropped index from collection: {collection}")
        except Exception as e:
            logger.error(f"Error dropping index from collection: {e}")
            raise e

    async def update_many_documents(self, collection: str, filter_condition: dict, update: dict):
        try:
            result = await self.mongo_client.get_collection(collection).update_many(filter_condition, update)
            logger.info(f"Updated many documents in collection: {collection}")
            return result
        except Exception as e:
            logger.error(f"Error updating many documents in collection: {e}")
            raise e