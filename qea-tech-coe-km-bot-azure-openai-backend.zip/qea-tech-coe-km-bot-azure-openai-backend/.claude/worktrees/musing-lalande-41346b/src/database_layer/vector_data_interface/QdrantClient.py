import os

from qdrant_client import models
from database_layer.vector_data_interface.CustomQdrantClient import CustomQdrantClient
from sentence_transformers import SentenceTransformer
from typing import Optional, Any
from utilities import utils
import copy
from utilities.AppLogger import global_logger

logger = global_logger


class QdrantDbClient:

    def __init__(self, db_path, embedding_model, similarity_metrics,
                 dense_model: Optional[str], sparse_model: Optional[str],
                 hybrid_search: Optional[bool] = False, local_downloaded_model_only: Optional[bool] = False):
        """
        This function initializes the client according to vector/fast-embed search feature
        :param db_path: Path of db creation
        :param embedding_model: Embedding model for vector search
        :param similarity_metrics: Distance metric for vector search
        :param dense_model: Dense Model for fast-embed search
        :param sparse_model:  Sparse model for fast-embed search
        :param hybrid_search: Config file parameter dictating search feature to be used
        """

        utils.ensure_path_exists(db_path)

        self.hybrid_search = hybrid_search
        self.client = CustomQdrantClient(path=db_path)
        self.local_downloaded_model_only = local_downloaded_model_only

        if hybrid_search:
            self.__set_sparse_and_dense_model(dense_model, sparse_model)
        else:
            self.__set_encoder_and_similarity_metric(embedding_model, similarity_metrics)

    # @staticmethod
    def __set_encoder_and_similarity_metric(self, embedding_model: str, similarity_metrics: str):
        """
        This method sets the encoder and similarity metric when hybrid search is false
        :param embedding_model: Embedding model for vector search
        :param similarity_metrics: Distance metric for vector search
        """
        self.encoder = SentenceTransformer(embedding_model,
                                           cache_folder=os.path.join(os.getenv('km_azure_home'), "Model"),
                                           local_files_only=self.local_downloaded_model_only)
        if similarity_metrics.upper() == "L2":
            self.similarity_metric = models.Distance.EUCLID
        elif similarity_metrics.upper() == "COSINE":
            self.similarity_metric = models.Distance.COSINE
        elif similarity_metrics.upper() == "DOT":
            self.similarity_metric = models.Distance.DOT

    def __set_sparse_and_dense_model(self, dense_model: str, sparse_model: str):
        """
        This method sets the dense and sparse models when hybrid search is true
        :param dense_model: Dense model to be loaded
        :param sparse_model: Sparse model to be loaded
        """

        self.client.set_model(embedding_model_name=dense_model,
                              cache_dir=os.path.join(os.getenv('km_azure_home'), "Model"),
                              local_files_only=self.local_downloaded_model_only)
        self.client.set_sparse_model(sparse_model,
                                     cache_dir=os.path.join(os.getenv('km_azure_home'), "Model"),
                                     local_files_only=self.local_downloaded_model_only)

    async def _get_create_collection(self, collection_name):
        """
        This method tends to achieve the get_or_create_collection effect of chroma db i.e.
        if the collection does not exist, create a new collection with that name and return it

        :param collection_name: Name of Collection to retrieve/create
        :return: Retrieved/Created Collection
        """
        # Only create the collection if it does not pre-exist
        if not self.client.collection_exists(collection_name=collection_name):
            try:
                self.create_collections(collection_name=collection_name)

            except Exception as e:
                logger.error(f"Error while creating '{collection_name}' :{e}")
                return None

        # Try to retrieve the collection
        try:
            return self.client.get_collection(collection_name=collection_name)
        except Exception as e:
            logger.error(f"Error in fetching collection from vectordb: {e}")
            return None

    def create_collections(self, collection_name):
        """
        Wrapper method over qdrant's client.create_collection which creates a collection with
        "collection_name"
        :param collection_name: Name of collection
        """
        try:
            if self.hybrid_search:
                self.client.create_collection(collection_name=collection_name,
                                              vectors_config=self.client.get_fastembed_vector_params(on_disk=
                                                                                                     True),
                                              sparse_vectors_config=self.client.get_fastembed_sparse_vector_params(
                                                  on_disk=
                                                  True))
            else:
                vectors_config = models.VectorParams(size=self.encoder.get_sentence_embedding_dimension(),
                                                     distance=self.similarity_metric)
                self.client.create_collection(collection_name=collection_name, vectors_config=vectors_config)

        except Exception as e:
            raise ValueError(f"Error in creating collection in vectordb: {e}")

    async def collection_has_data(self, collection_name):
        """
        This method verifies whether a collection has some existing data written over it
        :param collection_name: Name of the collection
        :return: True or False
        """
        collection = await self._get_create_collection(collection_name=collection_name)
        if collection.points_count != 0:
            return True
        return False

    async def format_query_return_type(self, retrieved_results, boolean: bool):
        """
        This function aims to construct a data structure for all the retrieval functions
        :param retrieved_results: These are the result(s) retrieved from either retrieval function
        :param boolean: This boolean value decides whether distance metric has to be included
        :return: The assembled response structure
        """
        final_result_list = []
        for result in retrieved_results:
            result_dict = {}
            # Storing respective UUID's and distances from the results
            result_dict.update(id=result.id)

            # Formatting the payload from qdrant db to a uniform structure
            payload_conditions = result.metadata if boolean and self.hybrid_search else result.payload

            result_dict.update(document=payload_conditions['document']) if self.hybrid_search \
                else result_dict.update(document=payload_conditions['original_document'])

            # This statement removes document/original_document key from payload and returns left-over dictionary
            result_dict.update(metadata=(payload_conditions.pop('document') if self.hybrid_search
                                         else payload_conditions.pop('original_document')) and payload_conditions)

            # Whether there is a distance metric attached with the result
            if boolean:
                result_dict.update(distance=result.score)
            # Assembling the unified structure
            final_result_list.append(result_dict)

        return final_result_list

    async def add_to_vector_db(self, collection_name: str, documents: list[str],
                               document_ids: Optional[list[str]] = None,
                               document_metadata: Optional[list[dict]] = None):
        """
        In this method, documents are added to the db using either fastembed or remote client
        To optimize performance, Qdrant supports batch loading of points while performing
        add operation.
        :param collection_name: Name of collection
        :param documents: Chunks
        :param document_ids: If ids are not provided, they will be generated automatically as UUIDs.
        :param document_metadata: Payload condition
        :return: True or False reflecting status of operation
        """

        try:
            if self.hybrid_search:
                # Requires wrapping code into if __name__ == '__main__' block
                await self._get_create_collection(collection_name)
                self.client.add(
                    collection_name=collection_name,
                    documents=documents,
                    metadata=document_metadata,
                    ids=document_ids
                )
            else:
                # Embedding the documents into their vector equivalent
                await self._get_create_collection(collection_name)
                vectors_config = [self.encoder.encode(doc).tolist() for doc in documents]

                # Create payload from document metadata
                for index, meta in enumerate(document_metadata):
                    meta.update({'original_document': documents[index]})

                self.client.upload_collection(
                    collection_name=collection_name,
                    ids=document_ids,
                    payload=document_metadata,
                    vectors=vectors_config
                )
            return True

        except Exception as e:
            logger.error(f"Caught an error while add operation: {e}")
            return None

    async def drop_collection(self, collection_name: str):
        """
        This method attempts to delete a collection
        :param collection_name: Name of the collection to be deleted
        :return: True/False
        """
        await self._get_create_collection(collection_name)
        # Attempting removal in accordance with official documentation
        if self.client.collection_exists(collection_name=collection_name):
            return self.client.delete_collection(collection_name=collection_name)
        else:
            raise ValueError(f"Collection {collection_name} not found in existing records!")

    async def query_vector_db(self, collection_name: str, query: str,
                              no_of_results_returned: int,
                              query_doc_condition: Optional[str] = None,
                              query_metadata_condition: Optional[dict] = None):
        """

        :param query_doc_condition: Optional keyword filtering condition
        :param collection_name: Name of collection to be searched
        :param query: Query Text
        :param no_of_results_returned: Limit the number of search results
        :param query_metadata_condition:Filter Condition
        :return: The response structure with id's, metadata, documents and distance
        """

        try:
            # Grouping the payload conditions
            await self._get_create_collection(collection_name)
            query_filter_conditions = []
            if query_metadata_condition:
                for key, value in query_metadata_condition.items():
                    query_filter_conditions.append(
                        models.FieldCondition(
                            key=key,
                            match=models.MatchValue(value=value)
                        )
                    )

            if self.hybrid_search:
                query_result = self.client.query(
                    collection_name=collection_name,
                    query_filter=models.Filter(
                        must=query_filter_conditions
                    ),
                    query_text=query[0],
                    limit=no_of_results_returned,
                )
            else:
                await self._get_create_collection(collection_name)
                # Embedding textual queries into their vector equivalent
                query_vector = self.encoder.encode(query).tolist()

                # Return format is List[ScoredPoint]
                query_result = self.client.search(
                    collection_name=collection_name,
                    query_filter=models.Filter(
                        must=query_filter_conditions
                    ),
                    search_params=models.SearchParams(hnsw_ef=128, exact=False),
                    query_vector=query_vector,
                    limit=no_of_results_returned,
                )

            if query_doc_condition:
                return await  self.__keyword_search(query_result, query_doc_condition)

            result = copy.deepcopy(query_result)
            return await self.format_query_return_type(retrieved_results=result, boolean=True)

        except Exception as e:
            logger.error(f"Caught an error while querying operation: {e}")

    async def __keyword_search(self, query_results: list[models.ScoredPoint], query_doc_condition):
        """
        This method is a custom hybrid search implementation for qdrant db, where it checks for
        keyword based matching after vector search results are obtained
        :param query_results: vector search results
        :param query_doc_condition: keyword to be matched
        :return:
        """

        hybrid_search_results = []

        for query_result in query_results:
            """
            If the payload dictionary document contains the keywords specified,
            consider the query result passed and add the query-result in hybrid_search_results[]
            """
            if query_doc_condition in query_result.payload["original_document"]:
                hybrid_search_results.append(query_result)

        return hybrid_search_results

    async def fetch_all_data(self, collection_name: str, filter_condition: Optional[dict] = None,
                             results_returned: Optional[int] = 10):
        """
        This method returns all or filtered points from existing collection
        :param collection_name: Name of collection
        :param filter_condition : Metadata condition
        :param results_returned: Number of results desired over the default limit
        :return: Matched documents, id's and their metadata
        """

        try:
            await self._get_create_collection(collection_name)
            if filter_condition:
                # Grouping the payload conditions
                query_filter_conditions = []

                for key, value in filter_condition.items():
                    query_filter_conditions.append(
                        models.FieldCondition(
                            key=key,
                            match=models.MatchValue(value=value)
                        )
                    )

                # Returns List[List[Record]]
                scroll_result = self.client.scroll(
                    collection_name=collection_name,
                    scroll_filter=models.Filter(
                        must=query_filter_conditions
                    ),
                    limit=results_returned,
                    with_payload=True,
                    with_vectors=True
                )

            else:
                scroll_result = self.client.scroll(
                    collection_name=collection_name,
                    with_payload=True,
                    with_vectors=True,
                    limit=results_returned
                )
            result = copy.deepcopy(scroll_result[0])
            return await self.format_query_return_type(retrieved_results=result, boolean=False)


        except Exception as e:
            logger.error(f"Caught an error while fetching collection data: {e}")

    async def get_data_with_id(self, collection_name: str, document_ids: list[str]):
        """
        This is the method for retrieving points by their ids
        :param collection_name: Name of collection
        :param document_ids: ID's of documents to be retrieved
        :return: Matched documents, id's and their metadata
        """

        try:
            await self._get_create_collection(collection_name)
            # Returns List[Record]
            data_from_ids = self.client.retrieve(
                collection_name=collection_name,
                ids=document_ids,
                with_vectors=False
            )
            result = copy.deepcopy(data_from_ids)
            return await self.format_query_return_type(retrieved_results=result, boolean=False)

        except Exception as e:
            logger.error(f"Caught an error while fetching data by id operation in qdrant db: {e}")

    async def delete_data_vectordb(self, collection_name: str, delete_ids: Optional[list[str]] = None,
                                   delete_condition: Optional[dict] = None):
        """
        This function deletes certain data from the collection on the basis of document ID's received
        :param collection_name: Name of collection
        :param delete_ids: ID's of documents to be deleted
        :param delete_condition: Metadata condition
        :return: True or None depending on operation status
        """
        try:
            if delete_ids:
                delete_result = self.client.delete(
                    collection_name=collection_name,
                    points_selector=models.PointIdsList(
                        points=delete_ids
                    )
                )
            else:
                # Create a list of FieldCondition items
                points_from_payload = [models.FieldCondition(key=key, match=models.MatchValue(value=value))
                                       for key, value in delete_condition.items()]
                delete_result = self.client.delete(
                    collection_name=collection_name,
                    points_selector=models.FilterSelector(
                        filter=models.Filter(
                            must=points_from_payload
                        )
                    ),
                )

            if delete_result.status == "completed":
                return True
            else:
                raise ValueError("Failed to delete points")

        except Exception as e:
            logger.error(f"Caught an error while deleting points from collection in qdrant db: {e}")
            return None

    async def __update_payload(self, collection_name: str, document_ids: list[str],
                               document_metadata: [list[dict]] = None):
        """
        This is private function which updates the payload points for specified document id's
        :param collection_name: The name of the collection
        :param document_ids: IDs of the document
        :param document_metadata: Metadata conditions of documents to be updated
        :return: Status or Error
        """
        try:

            result = self.client.set_payload(
                collection_name=collection_name,
                payload=document_metadata,
                points=document_ids
            )
            return result.status.lower()
        except Exception as e:
            logger.error(f"\nCaught an error while updating metadata in qdrant db: {e}")
            return e

    async def update_data_vectordb(self, collection_name: str, documents: list[str],
                                   document_ids: list[str], document_metadata: Optional[list[dict]] = None, ):
        """
        This method updates vectors, and it's payload filters if provided
        :param collection_name: Name of collection
        :param documents: List of documents to be updated
        :param document_ids: List of document ids
        :param document_metadata: Optional, additional payload conditions
        :return: In case of vector-only search returns a dictionary, for hybrid search a list is returned
        """
        failed_payload_updates = []
        try:
            await self._get_create_collection(collection_name)
            # Firstly update original document in payload
            for i in range(len(document_ids)):

                # Create Payload
                doc_meta = {}

                # Adding document to appropriate payload key based on search mode
                doc_meta.update({"document": f"{documents[i]}"}) if self.hybrid_search \
                    else doc_meta.update({"original_document": f"{documents[i]}"})

                if document_metadata:
                    doc_meta.update(document_metadata[i])

                status = await self.__update_payload(
                    collection_name=collection_name,
                    document_ids=[document_ids[i]],
                    document_metadata=doc_meta
                )

                # Checking return type for error
                if isinstance(status, ValueError):
                    logger.error(f"Error updating metadata:'{doc_meta}' for document id:'{document_ids[i]}'")
                    failed_dict = {'id': document_ids[i], 'metadata': doc_meta}
                    failed_payload_updates.append(failed_dict)
        except Exception as e:
            logger.error(f"Error occurred while creating payload: {e}")
            failed_payload_updates = None

        vectors_update_result = ""
        try:
            # For vector-only search, update the vector encoding
            if not self.hybrid_search and failed_payload_updates is not None:

                # Embedding the documents into their vector equivalent
                vectors_config = [self.encoder.encode(doc).tolist() for doc in documents]

                # Create Points
                points = [
                    models.PointVectors(id=doc_id, vector=vector)
                    for doc_id, vector in zip(document_ids, vectors_config)
                ]

                vectors_update_result = self.client.update_vectors(
                    collection_name=collection_name,
                    points=points
                )
                if vectors_update_result.status.lower() == "completed":
                    vectors_update_result = "completed"
                elif vectors_update_result == "" or isinstance(vectors_update_result, ValueError):
                    logger.error("Error while updating vectors")
                    vectors_update_result = "failed"

        except Exception as e:
            logger.error(f"Error occurred while configuring points/vectors: {e}")

        return failed_payload_updates if self.hybrid_search else {"failed_payload_updates": failed_payload_updates,
                                                                  "vectors_update_result": vectors_update_result}

    async def update_metadata_vectordb(self, collection_name: str, document_ids: list[str],
                                       document_metadata: [list[dict]] = None):
        """
        This is the public version to update only the metadata for a document, and NOT the document itself
        :param collection_name: Name of collection
        :param document_ids: ID's of the document
        :param document_metadata: Metadata condition(s) to be updated
        :return: Status or Error
        """
        try:
            await self._get_create_collection(collection_name)
            # If you try to update the original document, an error will be thrown
            if "original_document" in document_metadata or "document" in document_metadata:
                raise ValueError("Operation not allowed!")

            result = self.client.set_payload(
                collection_name=collection_name,
                payload=document_metadata,
                points=document_ids
            )
            return result.status.lower()

        except Exception as e:
            logger.error(f"\nCaught an error while updating metadata in qdrant db: {e}")
            return e

    def format_into_dict_list(self, retrieved_results, boolean: bool):
        """
        This function aims to construct a data structure for all the retrieval functions
        :param retrieved_results: These are the result(s) retrieved from either retrieval function
        :param boolean: This boolean value decides whether distance metric has to be included
        :return: The assembled response structure
        """
        ids, distances, metadatas, documents = [], [], [], []
        final_ans_dict = {}
        for result in retrieved_results:
            # Storing respective UUID's and distances from the results
            ids.append(result.id)
            if boolean:
                distances.append(result.score)

            # Formatting the payload from qdrant db to a uniform structure
            payload_conditions = result.metadata if boolean and self.hybrid_search else result.payload

            documents.append(payload_conditions['document']) if self.hybrid_search \
                else documents.append(payload_conditions['original_document'])

            # This statement removes document/original_document key from payload and returns left-over dictionary
            metadatas.append((payload_conditions.pop('document') if self.hybrid_search
                              else payload_conditions.pop('original_document')) and payload_conditions)
        # Assembling the unified structure
        final_ans_dict.update(ids=ids, metadatas=metadatas, documents=documents)
        if boolean:
            final_ans_dict.update(distances=distances)

        return final_ans_dict

    async def find_similar_doc(self, collection_name: str, user_query: list[str],
                               no_of_results: int, metadata_values: Optional[list[str]] = None,
                               skip_metadata_verification: Optional[bool] = True,
                               threshold: Optional[float] = 0,
                               tolerance: Optional[float] = 0,
                               filter_condition: Optional[dict] = None) -> tuple[None, None] | tuple[list[Any], bool]:

        """
            Function to retrieve data from vector DB

            :param filter_condition:
            :param collection_name: Collection name to search in
            :param user_query: The input based on which we are retrieving the documents
            :param metadata_values: the metadata properties to return, these values will be verified before returning results
            :param skip_metadata_verification: Set True if you want all metadata without any verification
            :param no_of_results: number of results to return
            :param threshold: similarity threshold to filter matches
            :param tolerance: tolerance value to lower threshold if no matches clear the threshold
            :return: list of matches, low confidence flag to reflect tolerance was applied
            """
        try:
            # Check if user query is empty
            if not user_query:
                raise ValueError("Empty User Query")

            # Query the vector database
            query_result_docs = await self.query_vector_db(collection_name=collection_name, query=user_query[0],
                                                           no_of_results_returned=no_of_results,
                                                           query_metadata_condition=filter_condition)

            # If no results, return None
            if not query_result_docs:
                return None, None

            # Calculate the maximum distance from the results
            max_dist = max(result['distance'] for result in query_result_docs)

            # Adjust the threshold if necessary
            low_confidence = False
            if threshold > max_dist >= threshold - tolerance:
                threshold = threshold - tolerance
                low_confidence = True
            elif not (threshold <= max_dist):
                return None, None

            # Filter the results based on the threshold and metadata
            final_query_answer = []
            for result in query_result_docs:
                if result['distance'] >= threshold:
                    # if metadata_values:
                    #     if skip_metadata_verification:
                    #         result['metadata'] = {key: result['metadata'].get(key, 'N/A') for key in metadata_values
                    #                               if
                    #                               key in result['metadata']}
                    #     else:
                    #         # If any required metadata is missing, skip this result
                    #         if any(key not in result['metadata'] for key in metadata_values):
                    #             continue
                    #         result['metadata'] = {key: result['metadata'].get(key, 'N/A') for key in
                    #                               metadata_values}

                    final_query_answer.append(result)

            # Sort the results by distance and return the top results
            # sorted_ans = sorted(final_query_answer, key=lambda x: x['distance'])
            # return sorted_ans[:no_of_results], low_confidence

            return final_query_answer, low_confidence

        except ValueError as ve:
            logger.error(f"ValueError occurred in find_similar_doc: {ve}")
            return None, None
        except Exception as e:
            logger.error(f"Unexpected error occurred in find_similar_doc: {e}")
            return None, None
