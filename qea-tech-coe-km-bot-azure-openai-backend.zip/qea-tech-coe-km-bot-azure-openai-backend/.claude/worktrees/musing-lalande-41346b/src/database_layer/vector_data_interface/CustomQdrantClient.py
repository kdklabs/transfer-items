from qdrant_client import QdrantClient
from database_layer.vector_data_interface.QdrantFastEmbed import CustomQdrantFastembed


class CustomQdrantClient(CustomQdrantFastembed, QdrantClient):
    pass


