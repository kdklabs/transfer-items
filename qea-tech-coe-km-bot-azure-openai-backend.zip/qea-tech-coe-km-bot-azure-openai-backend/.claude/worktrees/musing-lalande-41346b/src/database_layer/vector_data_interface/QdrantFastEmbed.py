from typing import Optional, Any

from qdrant_client.qdrant_fastembed import QdrantFastembedMixin


class CustomQdrantFastembed(QdrantFastembedMixin):
    def set_sparse_model(
            self,
            embedding_model_name: Optional[str],
            cache_dir: Optional[str] = None,
            threads: Optional[int] = None,
            **kwargs: Any,

    ) -> None:
        """
        Set sparse embedding model to use for hybrid search over documents in combination with dense embeddings.
        Args:
            embedding_model_name: One of the supported sparse embedding models. See `SUPPORTED_SPARSE_EMBEDDING_MODELS` for details.
                        If None, sparse embeddings will not be used.
            cache_dir (str, optional): The path to the cache directory.
                                       Can be set using the `FASTEMBED_CACHE_PATH` env variable.
                                       Defaults to `fastembed_cache` in the system's temp directory.
            threads (int, optional): The number of threads single onnxruntime session can use. Defaults to None.
        Raises:
            ValueError: If embedding model is not supported.
            ImportError: If fastembed is not installed.

        Returns:
            None
        """
        if embedding_model_name is not None:
            self._get_or_init_sparse_model(
                model_name=embedding_model_name,
                cache_dir=cache_dir,
                threads=threads,
                kwargs=kwargs
            )
        self._sparse_embedding_model_name = embedding_model_name