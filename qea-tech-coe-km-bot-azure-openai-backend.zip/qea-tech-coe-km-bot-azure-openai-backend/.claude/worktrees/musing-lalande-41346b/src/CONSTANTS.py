# database tables
DOCUMENT_DATA = "documents_data"
CONVERSATION_SUMMARY = "user_conversation_summary"
CACHED_QUESTION_ANSWER = "cached_question_answer"
file_extension_map = {
    "pdf": "pdf",
    "docx": "document",
    "pptx": "presentation",
    "doc": "document",
    "ppt": "presentation",
    "md": "markdown",
    "mp4": 'video',
    'ogv': 'video',
    'webm': 'video',
    'avi': 'video',
    'mov': 'video',
    'ogg': 'audio',
    'mp3': 'audio',
    'wav': 'audio',
    'm4a': 'audio',
}
KEY = "yGvG97s3OFaqpGNlQEpShsRriEIAeh6a8Q5jYEMk6Iw="
SPELL = "separator_string"
