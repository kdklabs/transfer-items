from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from fastapi import status

from db_service_layer.MongoDbServices import MongoAppDbService
from db_service_layer.VectorDbServices import VectorDb
from utilities.AppLogger import global_logger

from utilities.StartupUtilities import startup_utilities
from pydantic_models.view_models.ChatData import DeleteChat, DeleteCacheQuestion

router = APIRouter(tags=["Cached Question Operations"])
logger = global_logger


@router.get("/get_all_cached_question", description="Fetch all cached of question from db")
async def fetch_cached_question(vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service)):
    """
    Fetch all cached questions from the database.
    """
    try:
        all_conversation_data = await vector_db.fetch_all_cached_question()
        logger.info("All cached questions fetched successfully.")
        return JSONResponse(status_code=status.HTTP_200_OK, content={"all_db_content": all_conversation_data})
    except Exception as e:
        logger.error(f"Error fetching all cached questions: {e}")
        return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content={"error": str(e)})


@router.get("/delete_all_cached_question", description="Deletes all cached questions from db")
async def delete_all_cache_questions(vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service),
                                     mongo_app_db: MongoAppDbService = Depends(
                                         startup_utilities.get_mongo_app_db_services)
                                     ):
    """
    Delete all cached questions from the database.
    """
    try:
        app_db_cache_drop_status = await mongo_app_db.delete_all_cached_question()
        vector_db_cache_drop_status = await vector_db.delete_cache_collection()

        if app_db_cache_drop_status != 200 and vector_db_cache_drop_status != 200:
            logger.error(
                f"Error deleting all cached questions in both databases, app db status code: {app_db_cache_drop_status}, vector db status code: {vector_db_cache_drop_status}")
            return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                content={"delete_status": "failed in both databases"})

        elif app_db_cache_drop_status != 200:
            logger.error(f"Error deleting all cached questions in app db, status code: {app_db_cache_drop_status}")
            return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                content={"delete_status": "failed in app db"})

        elif vector_db_cache_drop_status != 200:
            logger.error(
                f"Error deleting all cached questions in vector db, status code: {vector_db_cache_drop_status}")
            return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                                content={"delete_status": "failed in vector db"})

        logger.info("All cached questions deleted successfully.")
        return JSONResponse(status_code=status.HTTP_200_OK, content={"delete_status": "success"})

    except Exception as e:
        logger.error(f"Error deleting all cached questions: {e}")
        return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content={"error": str(e)})


@router.post("/delete_single_cached_question", description="Deletes a single cached question from db")
async def delete_cache_questions(cached_question_id: DeleteCacheQuestion,
                                 vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service),
                                 mongo_app_db: MongoAppDbService = Depends(
                                     startup_utilities.get_mongo_app_db_services)
                                 ):
    """
    Delete a single cached question from the database.
    """
    try:
        cached_question_id = cached_question_id.question_id

        cached_question_data = await vector_db.fetch_cache_question_by_id(cached_question_id)
        if cached_question_data is None:
            logger.error(
                f"Error deleting cached question in app db with ID: {cached_question_id}, status code:404")
            return JSONResponse(status_code=404,
                                content={"delete_status": "Data not found in vector db"})
        app_db_cache_drop_status = await mongo_app_db.delete_cached_question(
            cached_question_data[0]['metadata']['question_app_db_id'])
        if app_db_cache_drop_status != 200:
            logger.error(
                f"Error deleting cached question in app db with ID: {cached_question_id}, status code: {app_db_cache_drop_status}")
            return JSONResponse(status_code=app_db_cache_drop_status,
                                content={"delete_status": "failed in app db"})
        vector_db_cache_drop_status = await vector_db.delete_cache_question(cached_question_id)
        if vector_db_cache_drop_status != 200:
            logger.error(
                f"Error deleting cached question in vector db with ID: {cached_question_id}, status code: {vector_db_cache_drop_status}")
            return JSONResponse(status_code=vector_db_cache_drop_status,
                                content={"delete_status": "failed in vector db"})
        logger.info(f"Cached question with ID: {cached_question_id} deleted successfully.")
        return JSONResponse(status_code=status.HTTP_200_OK, content={"delete_status": "success"})
    except Exception as e:
        logger.error(f"Error deleting cached question with ID: {cached_question_id}: {e}")
        return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content={"error": str(e)})
