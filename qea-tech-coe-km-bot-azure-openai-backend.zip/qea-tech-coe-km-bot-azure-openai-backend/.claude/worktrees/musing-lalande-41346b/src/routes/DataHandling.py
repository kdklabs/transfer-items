
import os

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from fastapi import status

from db_service_layer.MongoDbServices import MongoAppDbService
from db_service_layer.VectorDbServices import VectorDb
from github_automation.GithubAutomater import Github
from license_checker.validate_license import validate_license
from utilities.AppLogger import global_logger
from utilities.DButils import return_list_of_file_path
from utilities.StartupUtilities import startup_utilities
from pydantic_models.view_models.ChatData import FileFetch, DeleteChat, DBFetch

router = APIRouter(tags=["Database Operations"])
logger = global_logger


@router.get("/add-file-from-source-db", description="Loads downloaded markdown files to db")
async def create_db(vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service),
                    mongo_app_db: MongoAppDbService = Depends(
                        startup_utilities.get_mongo_app_db_services)
                    ):
    license_status, license_message = validate_license(os.getenv("km_bot_license_key"))

    if not license_status:
        bot_response = {"message": license_message}
        return JSONResponse(status_code=status.HTTP_403_FORBIDDEN, content=bot_response)

    local_folder_list = []
    github_folder_list = []
    sources_dict_list = startup_utilities.get_data_source()

    local_folder_update_status = None
    github_file_update_status = None

    # remove cache table from app db :
    if await mongo_app_db.delete_all_cached_question() == 200:
        app_db_cache_drop_status = True
    else:
        app_db_cache_drop_status = False

    # remove cache table from vector db
    if await vector_db.delete_cache_collection() == 200:
        vector_db_cache_drop_status = True
    else:
        vector_db_cache_drop_status = False

    if await vector_db.delete_source_data_collection() == 200:
        vector_db_source_data_drop_status = True
    else:
        vector_db_source_data_drop_status = False

    if await vector_db.delete_conversation_summary_collection() == 200:
        vector_db_conversation_summary_drop_status = True
    else:
        vector_db_conversation_summary_drop_status = False

    for sources_dict in sources_dict_list:
        source_type = sources_dict.get("type")
        if source_type == "local_folder":

            local_folder_list.append(sources_dict.get("path"))
        elif source_type == "github_wiki":

            github_repo_info = {
                "path": sources_dict.get("path"),
                "repo_name": sources_dict.get("repo_name"),
                "repo_owner_name": sources_dict.get("repo_owner_name")

            }

            github_folder_list.append(github_repo_info)

    if local_folder_list:

        for local_folder in local_folder_list:
            file_path_list = return_list_of_file_path(local_folder)

            local_folder_update_status = await vector_db.add_data_to_vectordb(file_path_list)

    if github_folder_list:
        for github_repo in github_folder_list:

            git_clone_status, git_clone_location = Github(github_repo['repo_name'], github_repo['repo_owner_name'],
                                                          github_repo['path']).clone_repository()
            if git_clone_status:
                github_file_path_list = return_list_of_file_path(git_clone_location)
                github_file_update_status = await vector_db.add_data_to_vectordb(github_file_path_list)

    db_update_status = {
        "github_files_add_status": github_file_update_status,
        "local_folders_add_status": local_folder_update_status,
        "app_db_cache_drop_status": app_db_cache_drop_status,

        "vector_db_cache_drop_status": vector_db_cache_drop_status,
        "vector_db_source_data_drop_status": vector_db_source_data_drop_status,
        "vector_db_conversation_summary_drop_status": vector_db_conversation_summary_drop_status

    }
    return JSONResponse(status_code=status.HTTP_200_OK, content=db_update_status)


@router.get("/update-github-wiki-file-db", description="Update github markdown files")
async def update_db(vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service)):
    license_status, license_message = validate_license(os.getenv("license_key"))

    if not license_status:
        bot_response = {"message": license_message}
        return JSONResponse(status_code=status.HTTP_403_FORBIDDEN, content=bot_response)
    github_repo_updates = []

    github_repo_updates_status = []
    sources_dict_list = startup_utilities.get_data_source()

    for sources_dict in sources_dict_list:
        source_type = sources_dict.get("type")
        if source_type == "github_wiki":
            github_repo_info = {
                "path": sources_dict.get("path"),
                "repo_name": sources_dict.get("repo_name"),
                "repo_owner_name": sources_dict.get("repo_owner_name")

            }
            github_repo_updates.append(github_repo_info)
    if github_repo_updates:
        for github_repo in github_repo_updates:
            file_name_to_delete = []
            file_updated, list_of_updated_files = Github(github_repo['repo_name'], github_repo['repo_owner_name'],
                                                         github_repo['path']).pull_repository()

            if file_updated:
                for files in list_of_updated_files:
                    file_name_to_delete.append(os.path.basename(files))

            await vector_db.check_if_file_exist(file_name_to_delete)
            file_update_status = await vector_db.add_data_to_vectordb(list_of_updated_files)
            github_repo_file_updated = {
                "repo_name": github_repo['repo_name'],
                "list_of_files": list_of_updated_files,
                "file_update_status": file_update_status
            }
            github_repo_updates_status.append(github_repo_file_updated)

        return JSONResponse(status_code=status.HTTP_200_OK,
                            content={"github_wiki_update_status": github_repo_updates_status})


@router.post("/get_all_db_content", response_model=DBFetch, description="Fetch all data from db")
async def fetch_db_content(db: DBFetch,
                           vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service)):
    all_db_data = await vector_db.fetch_all_data_from_db(db.results_returned)

    return JSONResponse(status_code=status.HTTP_200_OK, content={"all_db_content": all_db_data})


@router.post("/fetch_data_by_filename", response_model=FileFetch, description="Fetch Data by filename")
async def fetch_data_by_filename(files: FileFetch,
                                 vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service)):
    data_by_filename = await vector_db.fetch_data_by_filename(files.file_name, files.results_returned)

    return JSONResponse(status_code=status.HTTP_200_OK, content={"all_db_content": data_by_filename})


@router.get("/get_all_conversation_data", description="Fetch all data of chats from db")
async def fetch_conversation_content(vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service)):
    all_conversation_data = await vector_db.fetch_all_conversation_data()

    return JSONResponse(status_code=status.HTTP_200_OK, content={"all_db_content": all_conversation_data})


@router.post("/delete_conversation_data_by_ip", response_model=DeleteChat,
             description="Delete all data of chats from db for a particular ip")
async def delete_conversation_content(delete_chat: DeleteChat,
                                      vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service)):
    delete_status = await vector_db.delete_conversation_data(delete_chat.user_ip)

    return JSONResponse(status_code=status.HTTP_200_OK, content={"delete_status": delete_status})


@router.get("/delete_all_conversation_data",
            description="Delete all data of chats from db")
async def delete_all_conversation_content(delete_chat: DeleteChat,
                                          vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service)):
    delete_status = await vector_db.delete_all_conversation_data()

    return JSONResponse(status_code=status.HTTP_200_OK, content={"delete_status": delete_status})
