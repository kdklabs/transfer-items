import os

from fastapi import Depends, APIRouter

from fastapi.responses import JSONResponse

from fastapi import status, Request

from db_service_layer.MongoDbServices import MongoAppDbService
from db_service_layer.VectorDbServices import VectorDb
from license_checker.validate_license import validate_license

from llm_service_layer.llm_chains import LLMChains
from pydantic_models.view_models.ChatData import UserQuestion
from utilities.StartupUtilities import startup_utilities
from utilities.AppLogger import global_logger
from utilities.PromptLogger import PromptLogger

logger = global_logger
router = APIRouter(tags=["ChatOperations"])
prompt_logger = PromptLogger()


@router.post("/getqueryresponse", summary="Chat with bot")
async def chat_with_bot(request: Request, user_query: UserQuestion,
                        llm_model: LLMChains = Depends(startup_utilities.get_llm_model),
                        vector_db: VectorDb = Depends(startup_utilities.get_vector_db_service),
                        mongo_app_db: MongoAppDbService = Depends(
                            startup_utilities.get_mongo_app_db_services)) -> JSONResponse:
    bot_response = {}
    user_host_ip = request.client.host
    user_query = user_query.question
    license_status, license_message = validate_license(os.getenv("km_bot_license_key"))

    if not license_status:
        bot_response = {"message": license_message}
        return JSONResponse(status_code=status.HTTP_403_FORBIDDEN, content=bot_response)

    if os.getenv('llm_model') == "gpt3":
        bot_response = await llm_model.question_answer_with_online_llms(vector_db=vector_db, app_db=mongo_app_db,
                                                                        user_query=user_query,
                                                                        user_host_ip=user_host_ip)
        return JSONResponse(status_code=status.HTTP_200_OK, content=bot_response)
    elif os.getenv('llm_model') == "phi3":
        bot_response = await llm_model.question_answer_with_phi(vector_db=vector_db, user_query=user_query)
    return JSONResponse(status_code=status.HTTP_200_OK, content=bot_response)
