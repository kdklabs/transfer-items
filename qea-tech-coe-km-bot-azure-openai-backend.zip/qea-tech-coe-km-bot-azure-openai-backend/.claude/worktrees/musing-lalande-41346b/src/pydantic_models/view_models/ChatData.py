from typing import Optional, List

from pydantic import BaseModel, Field


class DeleteChat(BaseModel):
    user_ip: str


class FileFetch(BaseModel):
    file_name: str
    results_returned: int


class DBFetch(BaseModel):
    results_returned: int


class UserQuestion(BaseModel):
    question: str


class DeleteCacheQuestion(BaseModel):
    question_id: str


class BotAnswer(BaseModel):
    sentence: str
    source: int = Field(..., gt=0)


class BotSource(BaseModel):
    sourceURL: str
    result_type: str
    file_name: str
    page_no: Optional[int] = None
    header_title: Optional[str] = None
    start_time: Optional[str] = None


class QuestionAnswer(BaseModel):
    user_query: str
    bot_answer: List[BotAnswer]
    summary_sources: List[BotSource]
    other_sources: Optional[List[BotSource]] = None


class UpdateQuestionAnswer(BaseModel):
    bot_answer: List[BotAnswer]
    summary_sources: List[BotSource]
    other_sources: Optional[List[BotSource]] = None
