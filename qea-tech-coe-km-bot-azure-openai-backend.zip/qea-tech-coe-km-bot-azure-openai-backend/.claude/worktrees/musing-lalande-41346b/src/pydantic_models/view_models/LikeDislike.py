from typing import Optional, List

from pydantic import BaseModel


# Like Input Mode
class Like(BaseModel):
    question_id: str


# Like Response Model
class ResponseLike(BaseModel):
    question_id: str
    question: str
    like: int
    like_users: List[str]
    dislike: int
    dislike_users: List[str]
    user_ip: str


class Dislike(BaseModel):
    question_id: str
    feedback: Optional[str] = None


class ResponseDisLike(BaseModel):
    cache_app_db_delete_status: str
    cache_vector_db_delete_status : str
    feedback_db_insert_status: str



