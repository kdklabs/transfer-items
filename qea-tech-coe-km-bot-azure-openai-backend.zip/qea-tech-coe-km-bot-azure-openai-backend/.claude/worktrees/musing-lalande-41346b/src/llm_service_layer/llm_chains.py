from db_service_layer.MongoDbServices import MongoAppDbService
from db_service_layer.VectorDbServices import VectorDb
from utilities.utils import filter_duplicate_file_names, unique_id_generator
from utilities.AppLogger import global_logger
from utilities.PromptLogger import PromptLogger

logger = global_logger
prompt_logger = PromptLogger()


class LLMChains:
    def __init__(self, setup_utilities, config_dict):
        self.llm_model = setup_utilities.setup_llm_model()
        self.config_dict = config_dict
        # fetch the required threshold, tolerance , and no of results from config
        self.question_answers_threshold = float(self.config_dict.get("semantic_search").get(
            "question_answers").get("threshold"))
        self.question_answers_tolerance = float(self.config_dict.get("semantic_search").get(
            "question_answers").get("tolerance"))

        self.question_answers_results_documents = int(self.config_dict.get("semantic_search").get(
            "question_answers").get("no_of_results"))

    async def question_answer_with_phi(self, vector_db: VectorDb, user_query):
        doc_text = ""
        meta_dict_list = []
        logger.info("Starting the answer generation process")

        query_result = await vector_db.query_document_user_question(user_query,
                                                                    threshold=self.question_answers_threshold,
                                                                    tolerance=self.question_answers_tolerance,
                                                                    no_of_results=self.question_answers_results_documents,
                                                                    )
        question_to_bot = user_query
        logger.info(f"Completed fetching relevant context for questions")

        # fetch the data from db
        if query_result is not None:
            for i in range(len(query_result)):
                file_paths = {}
                doc_text += "\n" + query_result[i]["document"]
                file_paths["sourceURL"] = query_result[i]['metadata']["file_path"]
                file_paths["result_Type"] = "document"
                file_paths["file_name"] = query_result[i]['metadata']["file_name"]

                meta_dict_list.append(file_paths)

        logger.info("Starting Generating Answer")

        llm_answer = await self.llm_model.question_answer_custom_chain(question=question_to_bot, context=doc_text,
                                                                       )

        meta_dict_list = filter_duplicate_file_names(meta_dict_list)

        res = {
            "method": {
                "answer": [llm_answer],
                "summary_sources": meta_dict_list,
                "generated": True,
                "show_sources": True

            }
        }
        return res

    async def question_answer_with_online_llms(self, vector_db: VectorDb, app_db: MongoAppDbService,
                                               user_query: str,
                                               user_host_ip: str):
        # initialise the Prompt logger

        final_answer = ""
        show_sources = False
        logger.info("Starting the answer generation process")
        answer_generation = True
        previous_user_bot_chat_history = ""
        doc_text = "\n"
        meta_dict_list = []
        cached_question_id = ""
        final_chat_history = ""
        # initialise the Azure LLM

        # fetch client host

        logger.info(f"User IP : {user_host_ip}")

        # fetch the question from the cache
        question_retrieved_id = await vector_db.fetch_cached_question(user_query)

        # check if question is present in cache
        if question_retrieved_id is not None:

            cached_answer = await app_db.get_question_data_by_id(question_retrieved_id)

            # cached_question_id = unique_id_formatter(cached_answer[0].question_id)

            cached_answer_correct = self.llm_model.check_cache_answer_is_right_or_not(cached_answer['question'],
                                                                                      cached_answer['answer'],
                                                                                      user_query)

            prompt_logger.log_llm_data(
                "check_cache_answer_is_right_or_not",
                {
                    "Task": "Check Cached Answer is Right or Wrong",
                    "Cached Question ": cached_answer['question'],
                    "Cached Answer": cached_answer['answer'],
                    "Current User Query ": user_query,
                    "LLM Response ": cached_answer_correct

                })
            if cached_answer_correct:
                final_answer = cached_answer['answer']
                meta_dict_list = cached_answer['summary_sources']
                answer_generation = False
                show_sources = cached_answer['show_sources']
                prompt_logger.log_llm_data(
                    "question_answer_custom_chain",
                    {
                        "Task": "Question Answer",
                        "Original Question ": user_query,
                        "Modified Question ": "cached_question",
                        "Answer": final_answer,
                        "Previous Summary": "cached_question",
                        "Context ": "cached_question",
                        "Context Source": "cached_question"
                    })
                logger.info(f"Starting Fetching Previous Conversation")
                previous_conversation_summary, previous_conversation_list = await vector_db.fetch_chat_history(
                    str(user_host_ip))

                if previous_conversation_summary:
                    previous_summary = previous_conversation_summary
                else:
                    previous_summary = ""
                logger.info(f"Completed Fetching Previous Conversation")
                current_user_bot_conversation = f"Human :{user_query} \n AI : {final_answer}"

                if previous_conversation_list is not None:
                    if len(previous_conversation_list) == 0:
                        previous_user_bot_chat_history = ""
                    elif len(previous_conversation_list) == 3:
                        previous_conversation_list.pop(0)
                        previous_user_bot_chat_history = '\n'.join(
                            [f"{conversations}" for conversations in previous_conversation_list])
                    else:
                        previous_user_bot_chat_history = '\n'.join(
                            [f"{conversations}" for conversations in previous_conversation_list])

                final_chat_history = previous_user_bot_chat_history + current_user_bot_conversation
                conversation_summary = await self.llm_model.user_bot_conversation_summary(
                    chat_history=final_chat_history)
                conversation_summary = conversation_summary['text']
                prompt_logger.log_llm_data(
                    "user_bot_conversation_summary",

                    {
                        "Task": "Conversation Summary Generation",
                        "Current Conversation": final_chat_history,
                        "New Conversation Summary": conversation_summary

                    }
                )
                logger.info("Updating conversation history")
                await vector_db.create_update_user_chat_history(user_host_ip, conversation_summary,
                                                                current_user_bot_conversation)

        if answer_generation:

            # fetch previous history
            logger.info(f"Starting Fetching Previous Conversation")
            previous_conversation_summary, previous_conversation_list = await vector_db.fetch_chat_history(
                str(user_host_ip))

            if previous_conversation_summary:
                previous_summary = previous_conversation_summary
            else:
                previous_summary = ""
            logger.info(f"Completed Fetching Previous Conversation")

            # check if question is asked about any version
            logger.info(f"Starting fetching relevant context for questions")
            version_info = await self.llm_model.custom_llm_release_chain(user_query)
            prompt_logger.log_llm_data("custom_llm_release_chain",
                                       {"User Query": user_query,
                                        "Verion Info": version_info}
                                       )

            # check if there is any previous conversation for the userip and modify the question based on the conversation

            if previous_conversation_list is not None:

                conversation = f"{previous_conversation_list[-1]} \n Human : {user_query}"
                modified_question = await self.llm_model.question_rewrite_chain(previous_conversation=conversation)
                prompt_logger.log_llm_data(
                    "question_rewrite_chain",
                    {
                        "Previous Conversation": conversation,
                        "Original Question": user_query,
                        "Modified Question": modified_question

                    }
                )

                question_to_bot = modified_question
                query_result = await vector_db.query_document_user_question(modified_question,
                                                                            threshold=self.question_answers_threshold,
                                                                            tolerance=self.question_answers_tolerance,
                                                                            no_of_results=self.question_answers_results_documents,
                                                                            filter_version=version_info)
            else:
                query_result = await vector_db.query_document_user_question(user_query,
                                                                            threshold=self.question_answers_threshold,
                                                                            tolerance=self.question_answers_tolerance,
                                                                            no_of_results=self.question_answers_results_documents,
                                                                            filter_version=version_info)
                question_to_bot = user_query

            logger.info(f"Completed fetching relevant context for questions")

            # fetch the data from db
            if query_result is not None:
                for i in range(len(query_result)):
                    file_paths = {}
                    doc_text += "\n" + query_result[i]["document"]
                    file_paths["sourceURL"] = query_result[i]['metadata']["file_path"]
                    file_paths["result_Type"] = "document"
                    file_paths["file_name"] = query_result[i]['metadata']["file_name"]
                    # file_paths["file_name"] = query_result[i]["metadata_value"]['Header 1']
                    meta_dict_list.append(file_paths)

            # generate answer
            logger.info("Starting Generating Answer")

            llm_answer = await self.llm_model.question_answer_custom_chain(question=question_to_bot, context=doc_text,
                                                                           conversation_summary=previous_summary)

            current_user_bot_conversation = f"Human :{question_to_bot} \n AI : {llm_answer['text']}"

            if previous_conversation_list is not None:
                if len(previous_conversation_list) == 0:
                    previous_user_bot_chat_history = ""
                elif len(previous_conversation_list) == 3:
                    previous_conversation_list.pop(0)
                    previous_user_bot_chat_history = '\n'.join(
                        [f"{conversations}" for conversations in previous_conversation_list])
                else:
                    previous_user_bot_chat_history = '\n'.join(
                        [f"{conversations}" for conversations in previous_conversation_list])

            question_related_to_allowed_topics_status = self.llm_model.check_question_related_to_allowed_topics(
                question_to_bot)

            prompt_logger.log_llm_data(
                "check_question_related_to_allowed_topics",
                {
                    "Question to Bot": question_to_bot,
                    "Question Related to Allowed Topics": question_related_to_allowed_topics_status

                }
            )

            if question_related_to_allowed_topics_status == "True" or query_result is not None:
                final_chat_history = previous_user_bot_chat_history + current_user_bot_conversation
                conversation_summary = await self.llm_model.user_bot_conversation_summary(
                    chat_history=final_chat_history)
                conversation_summary = conversation_summary['text']
                prompt_logger.log_llm_data(
                    "user_bot_conversation_summary",

                    {
                        "Task": "Conversation Summary Generation",
                        "Current Conversation": final_chat_history,
                        "New Conversation Summary": conversation_summary

                    }
                )
            else:
                conversation_summary = previous_summary
                prompt_logger.log_llm_data(
                    "user_bot_conversation_summary",

                    {
                        "Task": "Conversation Summary Generation",
                        "Old Conversation Summary": conversation_summary

                    }
                )

            await vector_db.create_update_user_chat_history(user_host_ip, conversation_summary,
                                                            current_user_bot_conversation)

            logger.info("Updating conversation history")

            meta_dict_list = filter_duplicate_file_names(meta_dict_list)
            # llm_answer
            final_answer = llm_answer['text']
            final_answer = final_answer.replace("\n", "<br>")
            final_answer = final_answer.replace("<point>", "<br>")
            final_answer = final_answer.replace("<br><br><br>", "<br><br>")

            prompt_logger.log_llm_data(
                "question_answer_custom_chain",
                {
                    "Task": "Question Answer",
                    "Original Question ": user_query,
                    "Modified Question ": question_to_bot,
                    "Answer": final_answer,
                    "Previous Summary": previous_summary,
                    "Context ": doc_text,
                    "Context Source": meta_dict_list
                })

            logger.info("Completed Generating Answer")

            # cache question in app db
            answer_to_cache_or_not = await self.llm_model.check_bot_answer_the_question_or_not(question_to_bot,
                                                                                               final_answer)
            prompt_logger.log_llm_data(
                "check_bot_answer_the_question_or_not",
                {
                    "Task": "answer_to_cache_or_not",
                    "Original Question ": question_to_bot,

                    "Answer": final_answer,
                    "Bot Decision to cache": answer_to_cache_or_not

                })

            if answer_to_cache_or_not is True:
                cache_vector_id = unique_id_generator()
                show_sources = True
                cached_question_status, cached_question_id = await app_db.store_bot_generated_answer({
                    'question_vector_db_id': cache_vector_id,
                    'user_ip': user_host_ip,
                    'question': question_to_bot,
                    'answer': final_answer,
                    "summary_sources": meta_dict_list,
                    "show_sources": show_sources
                })

                # cached_question_id = unique_id_formatter(cached_question_status.question_id)

                # cache question in vectordb
                if cached_question_status:
                    await vector_db.store_question_in_cache(
                        question_uuid=cache_vector_id,
                        question=question_to_bot,
                        question_metadata={"question_app_db_id": str(cached_question_id)}

                    )
            # else:
            #     show_sources = False

        res = {
            "method": {
                "answer": [final_answer],
                "summary_sources": meta_dict_list,
                "generated": True,
                "question_id": str(cached_question_id),
                "show_sources": show_sources

            }
        }

        return res
