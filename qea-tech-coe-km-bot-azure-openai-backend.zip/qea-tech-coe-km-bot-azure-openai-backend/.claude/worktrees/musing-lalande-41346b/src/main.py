import os
import sys
from contextlib import asynccontextmanager
import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi import Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from license_checker.validate_license import validate_license
from routes.ChatInterface import router as ChatApiRouter
from routes.DataHandling import router as DBRouter
from routes.CachedQuestion import router as CachedQuestionRouter
from utilities.StartupUtilities import startup_utilities
from utilities.AppLogger import global_logger
from utilities.utils import get_current_mac_address

logger = global_logger
load_dotenv()


@asynccontextmanager
async def lifespan(app: FastAPI):
    await startup_utilities.db_setup()

    yield


app = FastAPI(lifespan=lifespan)

app.include_router(DBRouter, prefix="/database")
app.include_router(ChatApiRouter, prefix="/chat")
app.include_router(CachedQuestionRouter, prefix="/cached-question")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=False, access_log=True)


# 1. Liscen corruption
# 2. Date Expiry
# Mac maddress mismatch