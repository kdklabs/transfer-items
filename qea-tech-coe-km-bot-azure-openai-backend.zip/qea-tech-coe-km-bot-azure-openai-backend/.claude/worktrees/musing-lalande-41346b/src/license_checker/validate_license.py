from datetime import datetime, date

from cryptography.fernet import Fernet

from CONSTANTS import KEY, SPELL
from utilities.AppLogger import global_logger
from utilities.utils import get_current_mac_address

logger = global_logger


def decode_license(encrypted_data):
    """
    Decode the license data from the encrypted file.

    Parameters:
    - file_path: Path to the encrypted license file.

    Returns:
    - A dictionary with the decoded license information.
    """

    fernet = Fernet(KEY)

    decrypted_data = fernet.decrypt(encrypted_data).decode()

    # Split the decrypted data into its components
    mac_id, start_date, end_date, username = decrypted_data.split(SPELL)

    return {
        "mac_id": mac_id,
        "start_date": start_date,
        "end_date": end_date,
        "username": username
    }


def validate_license(license_key):
    """
    Validate the license by checking the MAC address and date validity.

    Parameters:
    - file_path: Path to the encrypted license file.

    Returns:
    - A tuple (is_valid, reason), where:
      - is_valid: A boolean indicating if the license is valid.
      - reason: A string providing the reason for the validation result.
    """
    try:
        # Decode the license file
        license_info = decode_license(license_key)

        # Get the current machine's MAC address
        current_mac = get_current_mac_address()

        # Validate MAC address
        if license_info['mac_id'] != current_mac:
            logger.error(
                f"MAC address mismatch !Please provide the mac address .Please use the right license or contact the Cognizant Technology Solutions for new license.")
            return False, "MAC address mismatch !Please provide the mac address .Please use the right license or contact the Cognizant Technology Solutions for new license."

        # Validate date range
        current_date = date.today()
        start_date = datetime.strptime(license_info['start_date'], '%Y-%m-%d').date()
        end_date = datetime.strptime(license_info['end_date'], '%Y-%m-%d').date()

        if not (start_date <= current_date <= end_date):
            logger.error(
                f"License has expired or is not yet valid! Please contact the Cognizant Technology Solutions for new license.")
            return False, "License has expired or is not yet valid! Please contact the Cognizant Technology Solutions for new license."

        # If all checks pass, the license is valid
        logger.success(f"License is valid.")
        return True, "License is valid."

    except Exception as e:

        logger.error(
            f"License seems to be Corrupted! Please contact the Cognizant Technology Solutions for new license.' :{e}")

        return False, f"License seems to be Corrupted! Please contact the Cognizant Technology Solutions for new license."
