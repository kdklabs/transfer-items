from utilities.AppLogger import global_logger

logger = global_logger


class MongoAppDbService:
    """
    This class provides the business logic and operations for the app database
    using the MongoClient as the database client.
    """

    def __init__(self, setup_utilities, db_type: str, db_config_dict: dict):
        """
        Initialize the MongoAppDbService with the given setup utilities, database type, and configuration dictionary.
        """
        self.question_answer_collection = "cached_question_answer"
        self.db_type = db_type
        self.database = setup_utilities.setup_mongo_database_client()
        self.db_name = db_config_dict.get("db_name")

    async def check_db_connection(self):
        """
        Check the connection to the MongoDB database.
        """
        try:
            dbs = await self.database.check_connection()
            if self.db_name in dbs:
                logger.info(f"App database: {self.db_type} Connection established")
            else:
                logger.error(f"App database: {self.db_type} Connection Failed")
                raise ConnectionError(f"App database: {self.db_type} Connection Failed")
        except ConnectionError as e:
            logger.error(f"Error checking DB connection: {e}")
            raise e

    async def get_question_data_by_id(self, question_id: str):
        """
        Fetches the question data by ID from the cached_question_answer collection.
        """
        if self.db_type == "mongo_db":
            try:
                question = await self.database.query_document_by_id(self.question_answer_collection, question_id)
                if question:
                    logger.info(f"Question data fetched successfully for ID: {question_id}")
                    return question
                else:
                    raise ValueError(f"No question found for ID: {question_id}")
            except ValueError as e:
                logger.error(f"Error in find cache question operation {e}")
                raise e

    async def store_bot_generated_answer(self, question_answer: dict):
        """
        Stores the bot generated answer in the cached_question_answer collection.
        """
        if self.db_type == "mongo_db":
            try:
                status, question_inserted_id = await self.database.add_single_document_to_db(
                    self.question_answer_collection,
                    question_answer)
                if status:
                    logger.info(f"Bot generated answer stored successfully with ID: {question_inserted_id}")
                    return status, question_inserted_id
                else:
                    raise RuntimeError(f"Failed to store bot generated answer")
            except RuntimeError as e:
                logger.error(f"Error in storing generated answer operation {e}")
                raise e

    async def get_all_cached_answer(self):
        """
        Fetches all cached answers from the cached_question_answer collection.
        """
        if self.db_type == "mongo_db":
            try:
                all_question_answer_list = await self.database.get_all_collection_document(
                    self.question_answer_collection)
                logger.info("All cached answers fetched successfully.")
                return all_question_answer_list
            except Exception as e:
                logger.error(f"Error in find all cache questions operation {e}")
                raise e

    async def get_cached_question_answer_by_id(self, id: str):
        """
        Fetches a cached question and answer by ID from the cached_question_answer collection.
        """
        if self.db_type == "mongo_db":
            try:
                query_document = await self.database.query_document_by_id(self.question_answer_collection, id)
                if query_document:
                    logger.info(f"Cached question and answer fetched successfully for ID: {id}")
                    return query_document
                else:
                    raise ValueError(f"No cached question and answer found for ID: {id}")
            except ValueError as e:
                logger.error(f"Error in find cache question operation {e}")
                raise e

    async def update_cached_question(self, question_id, updated_fields):
        """
        Updates the cached question with the given updated fields.
        """
        if self.db_type == "mongo_db":
            updated_fields = {k: v for k, v in updated_fields.items() if v is not None}
            if len(updated_fields) >= 1:
                try:
                    question = await self.database.query_document_by_id(self.question_answer_collection, question_id)
                    if not question:
                        raise ValueError(f"No question found for ID: {question_id}")
                    matched_count, modified_count, upsert_id = await self.database.update_one_document(
                        self.question_answer_collection,
                        filter_criteria={"_id": question_id},
                        update_operation=updated_fields)
                    if modified_count == 1:
                        logger.info(f"Cached question updated successfully for ID: {question_id}")
                        return 200
                    else:
                        raise RuntimeError(f"Failed to update cached question for ID: {question_id}")
                except RuntimeError as e:
                    logger.error(f"Error in file data update operation {e}")
                    raise e

    async def delete_cached_question(self, question_id):
        """
        Deletes a cached question by its ID.
        """
        try:
            question = await self.database.query_document_by_id(self.question_answer_collection, question_id)
            if question:
                try:
                    deleted_count = await self.database.delete_document(self.question_answer_collection,
                                                                        {"_id": question_id})
                    if deleted_count == 1:
                        logger.info(f"Cached question deleted successfully for ID: {question_id}")
                        return 200
                    else:
                        raise RuntimeError(f"Failed to delete cached question for ID: {question_id}")
                except RuntimeError as e:
                    logger.error(f"Error deleting cached question: {e}")
                    raise e
            else:
                raise ValueError(f"No question found for ID: {question_id}")
        except ValueError as e:
            logger.error(f"Error querying document by id in delete_cached_question: {e}")
            raise e

    async def delete_all_cached_question(self):
        """
        Deletes all cached questions.
        """
        try:
            deleted_count = await self.database.delete_all_document(self.question_answer_collection)

            if deleted_count:
                logger.info("All cached questions deleted successfully.")
                return 200
            else:
                raise RuntimeError("Failed to delete all cached questions")
        except RuntimeError as e:
            logger.error(f"Error deleting all cached questions: {e}")
            raise e
