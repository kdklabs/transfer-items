import os

from typing import Optional

from qdrant_client.http.exceptions import UnexpectedResponse

from CONSTANTS import file_extension_map, DOCUMENT_DATA, CONVERSATION_SUMMARY, CACHED_QUESTION_ANSWER
from parsers.MarkdownParser import parsed_markdown_text_metadata
from utilities.AppLogger import global_logger
from utilities.utils import get_current_time, unique_id_generator, reformat_parser_output

logger = global_logger


class VectorDb:

    def __init__(self, setup_utilities):

        self.vectordb_obj = setup_utilities.setup_vector_database_client()
        self.word_parser_obj = setup_utilities.setup_word_parser()
        self.ppt_parser_obj = setup_utilities.setup_ppt_parser()
        self.media_parser_obj = setup_utilities.setup_media_parser()
        # define the collection name and load them to config
        self.files_data = DOCUMENT_DATA
        self.conversation_summary = CONVERSATION_SUMMARY
        self.cache_question_answer = CACHED_QUESTION_ANSWER
        self.BREAK = "<break>"

    async def add_data_to_vectordb(self, list_of_file_path: list[str]):
        add_status = None
        try:

            # Iterating over the list of file paths
            for file_path in list_of_file_path:
                file_extension = os.path.splitext(file_path)[1][1:]
                file_type = file_extension_map.get(file_extension)

                # Verifying whether the file type is supported by the bot
                if file_extension in file_extension_map:

                    if file_type == "markdown":
                        logger.info(f"File {file_path}  parsing started")
                        unique_ids, page_content_list, metadata_list = parsed_markdown_text_metadata(file_path)
                        add_status = await self.vectordb_obj.add_to_vector_db(self.files_data,
                                                                              documents=page_content_list,
                                                                              document_ids=unique_ids,
                                                                              document_metadata=metadata_list)

                    # Handling the document and pdf file type under a single scenario
                    elif file_type == "document" or file_type == "pdf":
                        logger.info(f"File {file_path}  parsing started")

                        content = self.word_parser_obj.word_parser(file_path)
                        unique_ids, page_content_list, metadata_list = reformat_parser_output(content)

                        add_status = await self.vectordb_obj.add_to_vector_db(self.files_data,
                                                                              documents=page_content_list,
                                                                              document_ids=unique_ids,
                                                                              document_metadata=metadata_list)

                    elif file_type == "presentation":
                        logger.info(f"File {file_path}  parsing started")

                        unique_ids, page_content_list, metadata_list = reformat_parser_output(self.ppt_parser_obj.parse(

                            document_path=file_path

                        ))
                        add_status = await self.vectordb_obj.add_to_vector_db(self.files_data,
                                                                              documents=page_content_list,
                                                                              document_ids=unique_ids,
                                                                              document_metadata=metadata_list)

                    elif file_type == 'video' or file_type == 'audio':
                        logger.info(f"File {file_path}  parsing started")
                        file_object = {}
                        """
                        Todo : 
                        Move model to startup utilities 
                        
                        """

                        file_object.update(file_name=os.path.basename(file_path), file_path=file_path,
                                           type=file_extension)
                        parser_output = await self.media_parser_obj.parse(file_path, file_object=file_object)
                        unique_ids, page_content_list, metadata_list = reformat_parser_output(parser_output)
                        add_status = await self.vectordb_obj.add_to_vector_db(self.files_data,
                                                                              documents=page_content_list,
                                                                              document_ids=unique_ids,
                                                                              document_metadata=metadata_list)

                else:
                    logger.error(f"File {file_path} not supported")

                if add_status:
                    logger.success(f"File {file_path}  parsing completed")

            return add_status

        except Exception as e:

            logger.error(f"Not able to parse file \n Error : {str(e)}")

    async def check_if_file_exist(self, file_list):
        """
        :param file_list:
        :return:
        """

        for files in file_list:

            get_all_data_from_vectordb = await self.vectordb_obj.fetch_all_data(self.files_data,
                                                                                filter_condition={"file_name": files})

            if get_all_data_from_vectordb:
                try:

                    delete_status = await self.vectordb_obj.delete_data_vectordb(self.files_data,
                                                                                 delete_condition={"file_name": files})

                    return delete_status

                except Exception as e:
                    logger.error(f"Error caught while fetching the existing file info {e}")
                    return False

    async def fetch_data_by_filename(self, file_name: str, results_returned: int):
        try:

            get_all_data_from_vectordb = await self.vectordb_obj.fetch_all_data(self.files_data,
                                                                                results_returned=results_returned,
                                                                                filter_condition={
                                                                                    "file_name": file_name})
            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None

        except Exception as e:
            logger.error(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def fetch_all_data_from_db(self, results_returned: int):
        try:
            get_all_data_from_vectordb = await self.vectordb_obj.fetch_all_data(self.files_data,
                                                                                results_returned=results_returned)
            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None
        except Exception as e:
            logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def query_document_user_question(self, user_query: str, threshold: float, tolerance: float,
                                           no_of_results: Optional[int] = 3, filter_version: Optional[str] = None):

        if not user_query:
            raise ValueError("Empty User Query")

        try:
            if filter_version:
                user_query_result, _ = await self.vectordb_obj.find_similar_doc(self.files_data,
                                                                                user_query=[user_query],
                                                                                metadata_values=['file_path',
                                                                                                 'file_name'],
                                                                                no_of_results=no_of_results,

                                                                                skip_metadata_verification=True,
                                                                                threshold=threshold,

                                                                                tolerance=tolerance, filter_condition={
                        "release_version": filter_version})
                if user_query_result is None:
                    user_query_result, _ = await self.vectordb_obj.find_similar_doc(self.files_data,
                                                                                    user_query=[user_query],

                                                                                    metadata_values=['file_path',
                                                                                                     'file_name'],
                                                                                    skip_metadata_verification=True,
                                                                                    threshold=threshold,
                                                                                    tolerance=tolerance,
                                                                                    no_of_results=no_of_results)
            else:

                user_query_result, _ = await self.vectordb_obj.find_similar_doc(self.files_data,
                                                                                user_query=[user_query],

                                                                                metadata_values=['file_path',
                                                                                                 'file_name'],
                                                                                skip_metadata_verification=True,
                                                                                threshold=threshold,
                                                                                tolerance=tolerance,
                                                                                no_of_results=no_of_results)

            return user_query_result

        except IndexError as e:
            # logger.error(f"Error caught while querying question from cache  {e}")
            logger.error(f"Error caught while querying question from cache  {e}")
            return None

    async def create_update_user_chat_history(self, user_host_ip: str, chat_summary: str, user_bot_conversation: str):

        try:

            user_query_result = await self.vectordb_obj.fetch_all_data(collection_name=self.conversation_summary,
                                                                       filter_condition={"user_ip": user_host_ip}

                                                                       )

            if len(user_query_result) != 0:
                user_bot_conversation_history = user_query_result[0]['metadata']['conversation_history']

                if user_bot_conversation_history:
                    user_bot_conversation_list = user_bot_conversation_history.split(self.BREAK)
                    if len(user_bot_conversation_list) == 3:
                        user_bot_conversation_list.pop(0)
                        user_bot_conversation_list.append(user_bot_conversation)
                        user_bot_conversation_history = self.BREAK.join(user_bot_conversation_list)
                    else:
                        user_bot_conversation_list.append(user_bot_conversation)
                        user_bot_conversation_history = self.BREAK.join(user_bot_conversation_list)

                previous_chat_history = [chat_summary]

                metadata_list = [
                    {"conversation_history": user_bot_conversation_history, "history_update": str(get_current_time())}]

                update_status = await self.vectordb_obj.update_data_vectordb(collection_name=self.conversation_summary,
                                                                             document_ids=[user_query_result[0]['id']],
                                                                             documents=previous_chat_history,
                                                                             document_metadata=metadata_list)
                return update_status

            else:

                document_id = [unique_id_generator()]
                previous_chat_history = [chat_summary]

                metadata_list = [{"user_ip": user_host_ip, "conversation_history": user_bot_conversation + self.BREAK,
                                  "history_update": str(get_current_time())}]

                add_status = await self.vectordb_obj.add_to_vector_db(self.conversation_summary,
                                                                      documents=previous_chat_history,
                                                                      document_ids=document_id,
                                                                      document_metadata=metadata_list)
                return add_status

        except IndexError as e:
            # logger.error(f"Error caught while querying question from cache  {e}")
            logger.error(f"Error caught while update conversation summary {e}")
            return None

    async def fetch_chat_history(self, user_host_ip: str):

        user_query_result = await self.vectordb_obj.fetch_all_data(collection_name=self.conversation_summary,
                                                                   filter_condition={"user_ip": user_host_ip}, )

        if len(user_query_result) != 0:
            user_bot_conversation_history = user_query_result[0]['metadata']['conversation_history']
            if user_bot_conversation_history:
                user_bot_conversation_list = user_bot_conversation_history.split(self.BREAK)
                chat_history = user_query_result[0]['document']
                user_bot_conversation_list = [value for value in user_bot_conversation_list if
                                              value is not None and value != "" and value != []]
                return chat_history, user_bot_conversation_list
        else:
            return None, None

        #     last_updated_time = user_query_result['metadatas'][0]['history_update']  #     user_bot_conversation_list = user_query_result['metadatas'][0]['conversation_history']  #  #     if calculate_time_difference(last_updated_time) > 20:  #         chat_history = None  #         user_bot_conversation_list = []  #  #     else:  #         chat_history = user_query_result['documents'][0]  #  #     return chat_history,user_bot_conversation_list  # else:  #     return None

    async def fetch_all_conversation_data(self):

        try:
            get_all_data_from_vectordb = await self.vectordb_obj.fetch_all_data(self.conversation_summary)
            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None

        except Exception as e:
            logger.error(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def delete_conversation_data(self, ids: str):
        try:

            data_delete_status = await self.vectordb_obj.delete_data_vectordb(self.conversation_summary,
                                                                              delete_condition={"user_ip": ids})
            return data_delete_status

        except Exception as e:
            logger.error(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return False

    async def delete_all_conversation_data(self):
        try:
            delete_cache_status = await self.vectordb_obj.drop_collection(self.conversation_summary)
            if delete_cache_status:
                logger.info("All conversation data deleted successfully.")
                return 200
            else:
                raise UnexpectedResponse(status_code=400, reason_phrase="Failed to delete all conversation data")
        except Exception as e:
            logger.error(f"Error deleting all conversation data: {e}")
            raise e

    async def store_question_in_cache(self, question_uuid, question, question_metadata):
        # storing question and the id:of that question in app db
        question_id_list = [str(question_uuid)]
        question_list = [question]
        question_metadata_list = [question_metadata]

        cache_status = await self.vectordb_obj.add_to_vector_db(self.cache_question_answer, documents=question_list,
                                                                document_ids=question_id_list,
                                                                document_metadata=question_metadata_list)

        return cache_status

    async def fetch_cached_question(self, question):
        retrieved_question = await self.vectordb_obj.find_similar_doc(collection_name=self.cache_question_answer,
                                                                      user_query=[question],
                                                                      metadata_values=['question_app_db_id'],
                                                                      skip_metadata_verification=True,

                                                                      no_of_results=1, threshold=0.99, tolerance=0.05)

        if retrieved_question[0]:
            retrieved_id = retrieved_question[0][0]['metadata']['question_app_db_id']
            return retrieved_id

    async def fetch_all_cached_question(self):

        try:
            get_all_data_from_vectordb = await self.vectordb_obj.fetch_all_data(self.cache_question_answer)

            if get_all_data_from_vectordb:
                return get_all_data_from_vectordb
            else:
                return None
        except Exception as e:
            logger.error(f"Error caught while fetching all cached questions {e}")
            # logger.error(f"Error caught while fetching all cached questions {e}")
            return None

    async def delete_cache_question(self, ids: str):
        """
        Delete a single cached question from the database.
        """
        try:
            delete_ids = [ids]
            delete_status = await self.vectordb_obj.delete_data_vectordb(self.cache_question_answer, delete_ids)

            if delete_status:
                logger.info(f"Cached question with ID: {ids} deleted successfully.")
                return 200
            else:
                logger.error(f"Error deleting cached question with ID: {ids}")
                return 500

        except Exception as e:
            logger.error(f"Error deleting cached question with ID: {ids}: {e}")
            return 500

    async def delete_cache_collection(self):
        try:
            delete_cache_status = await self.vectordb_obj.drop_collection(self.cache_question_answer)
            if delete_cache_status:
                logger.info("All cached questions deleted successfully.")
                return 200
            else:
                raise UnexpectedResponse(status_code=400, reason_phrase="Failed to delete all cached questions")
        except Exception as e:
            logger.error(f"Error deleting all cached questions: {e}")
            raise e

    async def delete_source_data_collection(self):

        try:
            delete_source_collection_status = await self.vectordb_obj.drop_collection(self.files_data)
            if delete_source_collection_status:
                logger.info("All source data deleted successfully.")
                return 200
            else:
                raise UnexpectedResponse(status_code=400, reason_phrase="Failed to delete all source data")
        except Exception as e:
            logger.error(f"Error deleting all source data: {e}")
            raise e

    async def delete_conversation_summary_collection(self):
        try:
            delete_conversation_summary_status = await self.vectordb_obj.drop_collection(self.conversation_summary)
            if delete_conversation_summary_status:
                logger.info("All conversation summary data deleted successfully.")
                return 200
            else:
                raise UnexpectedResponse(status_code=400,
                                         reason_phrase="Failed to delete all conversation summary data")
        except Exception as e:
            logger.error(f"Error deleting all source data: {e}")
            raise e

    async def fetch_cache_question_by_id(self, question_id):
        try:
            cached_question_data = await self.vectordb_obj.get_data_with_id(collection_name=self.cache_question_answer,
                                                                            document_ids=[question_id])
            if cached_question_data:
                logger.info("Cached question identified successfully.")
                return cached_question_data
            else:
                logger.error(f"No cached question found for ID - {question_id}")
                return None
        except Exception as e:
            logger.error(f"Error fetching cached question by ID: {e}")
            return None
