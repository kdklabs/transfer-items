import json
import os

import pandas as pd
from datetime import datetime


class PromptLogger:

    def __init__(self):
        self.akm_home = os.getenv('km_azure_home')
        config_path = os.path.join(self.akm_home, "Config", "config.json")
        with open(config_path) as handle:
            self.config_dict = json.loads(handle.read())

        self.excel_log_file = None
        self.unique_key = datetime.now().strftime("%Y%m%d%H%M%S%f")

        self.excel_log_file_dir = os.path.join(self.akm_home, "LLM Logs")
        if os.path.exists(self.excel_log_file_dir) is False:
            os.mkdir(self.excel_log_file_dir)

    def log_llm_data(self, chain_name, data_dict: dict):
        self.excel_log_file = os.path.join(self.excel_log_file_dir,
                                           self.config_dict.get("llm_prompt_logger_config").get(chain_name))
        # Generate a unique key based on the current timestamp

        # Create a DataFrame with the provided data and the unique key
        df = pd.DataFrame([data_dict], index=[self.unique_key])

        # Try to read existing data from the Excel file (if it exists)
        try:
            existing_data = pd.read_excel(self.excel_log_file, index_col=0)
            df = pd.concat([existing_data, df])
        except FileNotFoundError:
            pass  # The file doesn't exist yet, ignore and continue

        # Write the DataFrame to the Excel file
        df.to_excel(self.excel_log_file)
        return True
