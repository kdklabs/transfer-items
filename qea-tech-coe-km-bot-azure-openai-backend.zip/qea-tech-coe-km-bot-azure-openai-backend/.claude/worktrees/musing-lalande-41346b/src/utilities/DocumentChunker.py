from typing import List
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter


def chunk_document_texts(text: str) -> List[Document]:
    text_splitter = RecursiveCharacterTextSplitter(
        # Set a really small chunk size, just to show.
        chunk_size=6000,
        chunk_overlap=500,
        length_function=len,
        is_separator_regex=False,
    )
    chunk_list = text_splitter.create_documents([text])
    return chunk_list
