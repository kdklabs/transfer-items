import os
import uuid
from datetime import datetime
import re

import numpy as np
from utilities.AppLogger import global_logger

logger = global_logger


def reformat_parser_output(segment_contents: list[dict]):
    page_content_list = []
    unique_ids = []
    document_metadata = []

    for segment_content in segment_contents:
        page_content_list.append(segment_content['segment_content'])
        unique_ids.append(segment_content['segment_id'])
        document_metadata.append(segment_content['segment_metadata'])

    return unique_ids, page_content_list, document_metadata


def get_current_time():
    current_time = datetime.now()
    formatted_time = current_time.strftime("%Y-%m-%d %H:%M:%S")

    return formatted_time


def calculate_time_difference(current_time: str):
    datetime_obj1 = datetime.strptime(current_time, '%Y-%m-%d %H:%M:%S')

    # Get the current datetime
    current_datetime = datetime.now()

    # Calculate the difference
    time_difference = current_datetime - datetime_obj1
    # Convert the time difference to minutes
    minutes_difference = time_difference.total_seconds() / 60

    return minutes_difference


def release_file_pattern_check(file_name: str):
    pattern = r"Release (\d+\.\d+\.\d+) - ([A-Za-z]+ \d+(?:st|nd|rd|th), \d{4})\.md"

    # Use re.match to check if the string matches the pattern
    match = re.match(pattern, file_name)

    if match:
        release_version = match.group(1)
        release_date = match.group(2)

        return True, release_version, release_date
    else:
        return False, None, None


def filter_duplicate_file_names(list_of_files):
    # Create a set to keep track of unique file_name values
    unique_names = set()
    # Create a new list to store the items with unique file_name values
    filtered_data = []
    for item in list_of_files:
        file_name = item["file_name"]
        if file_name not in unique_names:
            unique_names.add(file_name)
            filtered_data.append(item)
    return filtered_data


def unique_id_generator():
    """
    Generate a unique ID using UUID version 4.
    """
    return str(uuid.uuid4())


def unique_id_formatter(uuid_str):
    uuid_string = str(uuid_str)

    formatted_uuid = str("".join(uuid_string.split("-")))
    return formatted_uuid


def find_outlier_chunk(chunks_text):
    # creating the list with length of chunks
    len_chunks_text_list = [len(i) for i in chunks_text]
    chunk_index_to_remove = []
    chunks_to_remove = []
    cleaned_chunks_text = []
    # converting it to array
    data = np.array(len_chunks_text_list)

    # finding the outlier chunk
    q1 = np.percentile(data, 25)
    q3 = np.percentile(data, 75)
    iqr = q3 - q1
    lower_fence = q1 - 1.5 * iqr
    upper_fence = q3 + 1.5 * iqr
    outliers = np.where((data < lower_fence) | (data > upper_fence))


    # get the index of outliers in chunks_text
    if len(data[outliers]) != 0:
        outlier_chunk = [max(data[outliers])]

        for outlier_length in outlier_chunk:
            chunk_index_to_remove.append(len_chunks_text_list.index(int(outlier_length)))

        for chunk_index in chunk_index_to_remove:
            chunks_to_remove.append(chunks_text[chunk_index])

        for chunks in chunks_text:
            if chunks not in chunks_to_remove:
                cleaned_chunks_text.append(chunks)
        return cleaned_chunks_text

    return chunks_text


def ensure_path_exists(path):
    if not os.path.exists(path):
        try:
            os.makedirs(path)
            logger.success(f"Path '{path}' created successfully.")
        except OSError as e:
            logger.error(f"Error creating path '{path}': {e}")
    else:
        logger.info(f"Path '{path}' already exists.")


import uuid
from getmac import get_mac_address


def get_current_mac_address():
    """
    Retrieve the MAC address of the current machine.

    Returns:
    - Eth0 MAC address as string.
    """
    eth_mac = get_mac_address()
    eth_mac = eth_mac.replace(":", "").lower()

    return eth_mac
