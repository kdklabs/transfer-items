import json
import os
import sys

from loguru import logger
from dotenv import load_dotenv

load_dotenv()


class AppLogger:
    """
                Name : AppLogger Class
                Package : utilities
                Description : This Class is used for logging functionality

    """

    def __init__(self):
        """
                 Name : Constructor function
                 Package : utilities
                 Class : AppLogger Class
                 Description : The constructor initiates the following instance variables
                                    - app_logger : Object for logger class of loguru library
                                    - project_root : Root directory of project
                                    - logfile : Name of the log file
                 Parameters : None
                 Return : None

        """
        self.akm_home = os.getenv('km_azure_home')
        config_path = os.path.join(self.akm_home, "Config", "config.json")
        with open(config_path) as handle:
            config_dict = json.loads(handle.read())

        logger_config = config_dict.get("logger_config")
        self.app_logger = logger
        self.project_root = os.environ['km_azure_home']
        self.logfile = logger_config["logging_file"]
        self.logging_file_level = logger_config["logging_file_level"]
        self.rotation_size = logger_config["logging_file_rotation_size"]
        self.logging_file_format = logger_config["logging_file_format"]
        self.logging_console_level = logger_config["logging_console_level"]
        self.logging_console_format = logger_config["logging_console_format"]
        self.logging_color_level = logger_config["level_color"]

    def set_config(self):
        """
                Name : set_config
                Package : utilities
                Class : AppLogger Class
                Description :
                     - This function check's  whether the log folder exists or not and create if required
                     - It adds the logfile to the logger object to store the logs in logfile
                Parameters : None
                Return : Object of the logger class of loguru

        """

        if not os.path.exists(os.path.join(self.project_root, "Logs")):
            os.mkdir(os.path.join(self.project_root, "Logs"))

        log_file_path = os.path.join(self.project_root, "Logs", self.logfile)

        # console logger config
        self.app_logger.add(sink=sys.stderr,
                            level=self.logging_console_level,
                            format=self.logging_console_format,
                            enqueue=True,
                            backtrace=False,
                            diagnose=False,
                            colorize=True,
                            catch=False
                            )

        # self.app_logger.remove(0)
        # log file config
        self.app_logger.add(sink=log_file_path,
                            level=self.logging_file_level,
                            rotation=self.rotation_size,
                            format=self.logging_file_format,
                            enqueue=True,
                            backtrace=True,
                            diagnose=True,
                            )

        self.app_logger.level("TRACE", color=self.logging_color_level["TRACE_COLOR"])
        self.app_logger.level("INFO", color=self.logging_color_level["INFO_COLOR"])
        self.app_logger.level("DEBUG", color=self.logging_color_level["DEBUG_COLOR"])
        self.app_logger.level("SUCCESS", color=self.logging_color_level["SUCCESS_COLOR"])
        self.app_logger.level("WARNING", color=self.logging_color_level["WARNING_COLOR"])
        self.app_logger.level("ERROR", color=self.logging_color_level["ERROR_COLOR"])
        self.app_logger.level("CRITICAL", color=self.logging_color_level["CRITICAL_COLOR"])

        return self.app_logger

    def get_logger(self):
        return self.app_logger


logger_obj = AppLogger()
logger_obj.set_config()
global_logger = logger_obj.get_logger()
global_logger.info("Starting Bot")
