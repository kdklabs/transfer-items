import os
import datetime
import comtypes.client
import docx
from typing import List, Dict

from utilities.AppLogger import global_logger
logger = global_logger

class Utilities(object):
    """
                 Name : Utilities Class
                Package : utilities
                Description : This Class is used for creating utilities function
                              used in processing data

    """

    def docx_to_pdf(self, word_path):
        if word_path[-4:] == 'docx':
            pdf_path = word_path[:-4] + "pdf"
        elif word_path[-3:] == 'doc':
            pdf_path = word_path[:-3] + "pdf"
        else:
            return None

        # Load the Word document using the docx library
        if word_path.endswith('.docx'):
            doc = docx.Document(word_path)
        else:
            # Convert .doc to .docx
            docx_path = self.convert_doc_to_docx(word_path)
            if not docx_path:
                return None
            doc = docx.Document(docx_path)

        # Remove headers and footers from all sections
        for section in doc.sections:
            self.clear_headers_and_footers(section.header)
            self.clear_headers_and_footers(section.footer)

        # Save the modified Word document
        modified_docx_path = "modified_" + os.path.basename(word_path)
        doc.save(modified_docx_path)

        # Save the Word document as a PDF using Microsoft Word
        word = comtypes.client.CreateObject("Word.Application")
        docx_path = os.path.abspath(modified_docx_path)
        pdf_path = os.path.abspath(pdf_path)

        pdf_format = 17  # PDF file format code
        word.Visible = False
        in_file = word.Documents.Open(docx_path)
        in_file.SaveAs(pdf_path, FileFormat=pdf_format)
        in_file.Close()

        # Quit Microsoft Word
        word.Quit()

        # Remove the temporary modified Word document
        os.remove(modified_docx_path)
        return pdf_path

    def convert_doc_to_docx(self, doc_path):
        word = comtypes.client.CreateObject("Word.Application")
        try:
            docx_path = os.path.splitext(doc_path)[0] + ".docx"
            doc = word.Documents.Open(doc_path)
            doc.SaveAs(docx_path, FileFormat=12)  # FileFormat for .docx
            doc.Close()
            return docx_path
        except Exception as e:
            logger.error("Error converting .doc to .docx:", e)
            return None
        finally:
            word.Quit()

    def clear_headers_and_footers(self, part):
        for paragraph in part.paragraphs:
            for run in paragraph.runs:
                run.clear()

    def generate_id(self, content_text):
        return str(hash(str(int(datetime.datetime.timestamp(datetime.datetime.now()) * 1000)) + content_text))

    @staticmethod
    def reformat_document_parser(parsed_data: List[Dict], file_path:str) -> List[Dict]:
        """
        This function parses the old parser format into a homogenous structure
        :param parsed_data: Parser output of WordDocumentParser
        :return: List of Document Segments
        """
        parsed_output = []
        segment = {}
        segment_metadata = {}
        heading_concatenation = ""
        segment_count = 0
        file_name = os.path.basename(file_path)

        for i in range(len(parsed_data)):
            dict_element = parsed_data[i]
            # If the dict segment does not have paragraphs, only heading
            if 'header_content' not in dict_element:
                heading_concatenation += " " + dict_element.get('header')

            # Dict Segment has paragraph-text or 'header_content'
            else:
                segment_count += 1
                heading_concatenation += " " + dict_element.get('header')

                segment_metadata.update(file_path=file_path,
                                        file_name=file_name,
                                        heading=heading_concatenation,
                                        segment_number=segment_count,
                                        segment_type='heading')

                segment.update(segment_id=dict_element.get('id'),
                               segment_content=dict_element.get('header_content'),
                               segment_metadata=segment_metadata)

                parsed_output.append(segment)
                heading_concatenation = ""
                segment = {}
                segment_metadata = {}

        # If the document only consisted of headings
        if not parsed_output and heading_concatenation:
            last_dict_element = parsed_data[len(parsed_data) - 1]
            segment_metadata.update(file_path=file_path,
                                    file_name=file_name,
                                    heading=heading_concatenation,
                                    segment_number=1,
                                    segment_type='heading')

            segment.update(segment_id=last_dict_element.get('id'),
                           segment_content=heading_concatenation,
                           segment_metadata=segment_metadata)
            parsed_output.append(segment)

        return parsed_output
