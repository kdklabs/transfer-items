import os

from utilities.AppLogger import global_logger
logger = global_logger
def convert_dict_values_to_strings(input_dict):
    """
    Recursively convert all values in a dictionary to strings.

    Args:
    input_dict (dict): The input dictionary to be converted.

    Returns:
    dict: A new dictionary with all values converted to strings.
    """
    result_dict = {}
    for key, value in input_dict.items():
        if isinstance(value, dict):
            # Recursively convert values if they are dictionaries.
            result_dict[key] = convert_dict_values_to_strings(value)
        else:
            # Convert non-dictionary values to strings.
            result_dict[key] = str(value)
    return result_dict


def return_list_of_file_path(file_dir, ignore_folders=None):
    if ignore_folders is None:
        ignore_folders = [".git"]
    try:
        file_path_list = []
        for root, dirs, files in os.walk(file_dir):
            # Exclude folders listed in ignore_folders
            dirs[:] = [d for d in dirs if d not in ignore_folders]

            for file in files:
                md_file_path = os.path.join(root, file)
                file_path_list.append(md_file_path)
        return file_path_list
    except Exception as e:
        logger.error(f"File path parsing error {e}")