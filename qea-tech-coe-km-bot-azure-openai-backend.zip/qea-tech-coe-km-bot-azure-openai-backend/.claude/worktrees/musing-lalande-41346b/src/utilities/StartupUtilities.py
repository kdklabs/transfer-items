import json
import os
import threading

import whisper
from dotenv import load_dotenv

from database_layer.mongo_data_interface.MongoClient import MongoDbConnector
from database_layer.vector_data_interface.QdrantClient import QdrantDbClient
from db_service_layer.MongoDbServices import MongoAppDbService
from db_service_layer.VectorDbServices import VectorDb
from llm_clients.AzureOpenAi import AzureOpenAILlm
from llm_clients.MicrosoftPhi import Phi3
from llm_service_layer.llm_chains import LLMChains
from parsers.WordParser import WordParser
from parsers.PPTParser import PPTParser
from parsers.media_parsers.MediaTranscribe import MediaTranscribe


class SetUpUtilities(object):

    def __init__(self):
        load_dotenv()
        self.akm_home = os.getenv('km_azure_home')

        self.repo_name = os.getenv('repo_name')
        self.repo_owner_name = os.getenv('repo_owner_name')
        self.user_name = os.getenv('user_name')
        self.user_token = os.getenv('user_token')
        self.llm_model_name = os.getenv('llm_model')

        config_path = os.path.join(self.akm_home, "Config", "config.json")
        with open(config_path) as handle:
            self.config_dict = json.loads(handle.read())

    def get_akm_home(self):
        return self.akm_home

    def load_github_details(self):
        github_details = {
            "repo_name": self.repo_name,
            "repo_owner_name": self.repo_owner_name,
            "user_name": self.user_name,
            "user_token": self.user_token}

        return github_details

    def setup_vector_database_client(self):
        db_name = self.config_dict.get("databases").get("vector_db_type")
        if db_name == "qdrant_db":
            db_path = os.path.join(self.akm_home, self.config_dict.get("qdrant_db").get("db_path"))

            embedding_model = self.config_dict.get("qdrant_db").get("embedding_model")
            similarity_metrics = self.config_dict.get("qdrant_db").get("similarity_metrics")
            dense_model = self.config_dict.get("qdrant_db").get("dense_model")
            sparse_model = self.config_dict.get("qdrant_db").get("sparse_model")
            hybrid_search = self.config_dict.get("qdrant_db").get("hybrid_search")
            local_downloaded_model_only = self.config_dict.get("qdrant_db").get("local_downloaded_model_only")
            qdrant_db_client_obj = QdrantDbClient(db_path, embedding_model, similarity_metrics, dense_model,
                                                  sparse_model, hybrid_search,local_downloaded_model_only)

            return qdrant_db_client_obj

        else:
            raise ValueError("Set DB Value in Config File")

    def setup_mongo_database_client(self):
        db_name = os.getenv("app_db_type")
        if db_name == "mongo_db":
            db_parameters = {}
            db_parameters.update(
                db_name=os.getenv("kmbot_db_name"),
                db_username=os.getenv("kmbot_db_username"),
                db_password=os.getenv("kmbot_db_password"),
                db_host=os.getenv("kmbot_db_host"),
                db_port=os.getenv("kmbot_db_port")
            )
            mongodb_client_obj = MongoDbConnector(db_parameters)
            return mongodb_client_obj

        else:
            raise ValueError("Set DB Value in ENV File")

    def setup_word_parser(self):
        model_id = "pierreguillou/lilt-xlm-roberta-base-finetuned-with-DocLayNet-base-at-linelevel-ml384"
        return WordParser(model_id)

    def setup_media_parser(self):
        whisper_models = os.path.join(os.environ['km_azure_home'], 'Model', 'whisper')
        media_transcribe_model = whisper.load_model('small.en', download_root=whisper_models)
        return MediaTranscribe(media_transcribe_model)

    def setup_ppt_parser(self):
        return PPTParser()

    def setup_data_source(self):
        data_source_dict_list = self.config_dict.get("data_source")
        return data_source_dict_list

    def setup_llm_model(self):
        model_config_dict = {}
        if self.llm_model_name == "gpt3":
            model_config_dict['deployment_name'] = self.config_dict.get("llm_config").get("gpt3").get("deployment_name")
            model_config_dict['model_name'] = self.config_dict.get("llm_config").get("gpt3").get("model_name")
            model_config_dict['temperature'] = float(self.config_dict.get("llm_config").get("gpt3").get("temperature"))
            model_config_dict['token_length_factor'] = float(
                self.config_dict.get("llm_config").get("gpt3").get("token_length_factor"))
            model_config_dict['max_total_tokens'] = int(
                self.config_dict.get("llm_config").get("gpt3").get("max_total_tokens"))
            model_config_dict['allowed_topics'] = self.config_dict.get("allowed_topics")
            return AzureOpenAILlm(model_config_dict)
        elif self.llm_model_name == "phi3":
            model_path = os.path.join(self.akm_home, "Model", "llamamodel", "Phi-3-mini-4k-instruct-q4.gguf")
            print(model_path)
            phi3_config = self.config_dict.get("llm_config").get("phi3")
            phi3_model = Phi3(model_path,phi3_config)
            return phi3_model


class StartUp(object):
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
                    cls._instance._init_connections()
        return cls._instance

    def _init_connections(self):
        self.setup_utilities = SetUpUtilities()
        self.config_dict = self.setup_utilities.config_dict
        self.vector_db_service = VectorDb(self.setup_utilities)
        self.mongo_db_services = MongoAppDbService(self.setup_utilities,
                                                   self.config_dict.get("databases").get("app_db_type"),
                                                   self.config_dict.get(
                                                       self.config_dict.get("databases").get("app_db_type")))

        self.github_user_config = self.setup_utilities.load_github_details()

        self.llm_model = LLMChains(self.setup_utilities, self.config_dict)

    def get_vector_db_service(self):
        return self.vector_db_service

    def get_mongo_app_db_services(self):
        return self.mongo_db_services

    def get_data_source(self):
        return self.setup_utilities.setup_data_source()

    def get_github_config(self):
        return self.github_user_config

    def get_config_dict(self):
        return self.config_dict

    def get_llm_model(self):
        return self.llm_model

    async def db_setup(self):
        # await self._check_vector_db_collections()
        await self.mongo_db_services.check_db_connection()


startup_utilities = StartUp()
