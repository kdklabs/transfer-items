import re

row_serial_no = 1


def parse_table(shape):
    """
    Makes List of Dictionaries from Table
    keys : Column Headings (Example -> User Story ID, Test Scenario ID, ...)
    Initially, 'initialize_keys' would be false
    After iterating over a row, if all the cells had the same structure i.e. height => This is the Header row
    Extract the header row content and use them as keys for dictionary structure
    The Final Structure would be:
    [{header: True/False}, {header_key1: Row1_cell_obj, header_key2: Row1_cell_obj, ...}, {header_key1: Row2_cell_obj, {header_key2: Row2_cell_obj}, ...]
    IFF the table has only one row:
    [[header1, header2, header3, ...]] such that length os list = 1 gives us inference that only one row is associated
    """

    # This is the row index from which we start including the text in to the table dictionary
    start_index = 1

    # In case when headers are not present, and origin cells are merged, this is used to track the row serial number
    global row_serial_no

    # Declaring the header list which may or may not be present for a table
    header_list = []

    # Somtimes a table may only have one set of row, we need to return it as a list as is
    uni_row = False

    # Homogeneity of first row cells
    flag = False

    rows = shape.table.rows

    # This method returns this list
    table_list_of_dict = []

    # Table must have non-zero rows
    if len(rows) > 0:

        # Understanding the structure of the First/Header Row
        first_row = rows[0]

        # Checking whether row is of homogenous structure
        origin_cell_height = first_row.cells[0].span_height

        # Iterating over the first row
        for cell in first_row.cells:
            # Check whether for the first row, is each cell of equal dimension or not i.e. homogeneity of row cells
            if cell.span_height != origin_cell_height:
                start_index = 0
                flag = True
                break

        # Check whether the table consists of only one row
        if first_row.cells[0].span_height == len(rows):
            cell_txt = first_row.cells[0].text
            uni_row = True

        """
        If the Top Row is not homogenous, it's a clear indication that First Row is NOT a descriptive HEADER 
        Since, Header column is not present, the keys for table dictionary would be the row number
        Structure: [{Row_1: [cell1_text, cell2_text, ...]}, {Row_2: [cell1_text, cell2_text, ...]}, ...]
        Therefore, the de-limiter in this case is '_' to fetch the row needed
        """

        # First row of table was non-homogenous
        if flag:
            table_list_of_dict.append({
                'headers': False
            })
            row_items_list = []

        # Taking action for single rowed table
        elif uni_row:

            table_list_of_dict.append({
                'headers': False
            })

            uni_row_list = get_first_row_text(rows[0])
            table_list_of_dict.append({
                'Row_1': uni_row_list
            })

        else:
            table_list_of_dict.append({
                'headers': True
            })

            # Extracting Header Text from First Column and storing in List
            header_list = get_first_row_text(rows[0])

        # Constructing a Meaningful Data Structure : List[Dictionary]
        for i in range(start_index, len(rows)):
            if rows[i].cells[0].is_merge_origin and header_list:
                table_list_of_dict.append(structure_merged_row_text(rows[i], i, rows, header_list))
                row_serial_no += 1
            elif rows[i].cells[0].is_merge_origin and header_list == []:
                table_list_of_dict.append(structure_merged_row_text(rows[i], i, rows, header_list))
                row_serial_no += 1
            elif rows[i].cells[0].text == "":
                continue
            else:
                table_list_of_dict.append(structure_row_text(rows[i], i, header_list))
                row_serial_no += 1
        row_serial_no = 1

    return str(table_list_of_dict)

def structure_row_text(row, row_index: int, header_list: list):
    row_dictionary = {}
    row_list = []
    cells = row.cells
    iteration_range = len(header_list) if len(header_list) < len(cells) else len(cells)
    for i in range(iteration_range):
        if header_list:
            row_dictionary.update([(header_list[i], filter_cell_text(cells[i]))])
        else:
            row_list.append(filter_cell_text(cells[i]))

    if header_list:
        return row_dictionary
    else:
        row_index_str = f"Row_{row_index + 1}"
        row_dictionary.update([(row_index_str, row_list)])
        return row_dictionary


def structure_merged_row_text(row, row_index, rows, header_list: list):
    # Keep calculating the range of width covered to access below cell text

    # If the table contains headers
    row_dictionary = {}
    # If the table does not contain headers
    row_list = []
    merged_text_list = []
    merged_height = row.cells[0].span_height
    height_range_covered = 0
    cells = row.cells
    for i in range(len(cells)):

        if cells[i].span_height < merged_height:

            # Firstly extracting the text from the un-merged cell
            cell_text = filter_cell_text(cells[i])
            merged_text_list.append(cell_text)

            height_range_covered += cells[i].span_height

            while height_range_covered < merged_height:
                row = rows[row_index + height_range_covered]
                cell = row.cells[i]
                cell_text = filter_cell_text(cell)
                merged_text_list.append(cell_text)
                # Calculating how much height did this current cell cover
                height_range_covered += cell.span_height

            # Checking if header_list is empty i.e. Whether table has headers in it
            if header_list:
                row_dictionary.update([(header_list[i], merged_text_list)])
            else:
                row_list.append(merged_text_list)
            height_range_covered = 0
            merged_text_list = []
        elif header_list:
            cell_text = filter_cell_text(cells[i])
            row_dictionary.update([(header_list[i], cell_text)])
        else:
            cell_text = filter_cell_text(cells[i])
            row_list.append(cell_text)

    if header_list:
        return row_dictionary
    else:
        index_str = f"Row_{row_serial_no}"
        row_dictionary.update([(index_str, row_list)])
        return row_dictionary


def filter_cell_text(cell):
    return re.sub(r'[\x00-\x1f\x7f-\x9f]', '', cell.text.strip())


def get_first_row_text(row):
    row_list = []
    for cell in row.cells:
        if cell.text.strip() == "":
            continue
        row_list.append(filter_cell_text(cell))
    return row_list
