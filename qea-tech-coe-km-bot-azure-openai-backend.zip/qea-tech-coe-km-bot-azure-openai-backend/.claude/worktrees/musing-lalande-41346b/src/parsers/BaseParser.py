from abc import ABC, abstractmethod


class BaseParser(ABC):
    """
    This is the base class for all parsers, use this to create new parsers, it has an abstract method parse, each parser
    must implement its own parse method.
    """
    @abstractmethod
    def parse(self, path, **kwargs):
        pass
