import os.path
import pathlib
import uuid
from parsers.media_parsers.VideoTextExtraction import VideoTextExtraction
from parsers.BaseParser import BaseParser
from utilities.AppLogger import global_logger

logger = global_logger


class MediaTranscribe(BaseParser):
    """
    Use whisper to transcribe both audio and video
    """

    def __init__(self, model, auto_approve_flag="False"):
        self.transcribe_model = model
        self.auto_approve = auto_approve_flag

    async def parse(self, video_file_path, **kwargs):
        """
        Args:
            video_file_path: File Path
            kwargs: file_object (containing: "file_name", "type" and "file_path"), image_handler
        Returns:
            List[Dict] - transcript chunked by 60 seconds
        """
        video_object = kwargs.get("file_object")  # add video using this
        image_handler = None
        page_title_to_be_used = video_object.get("file_name")
        video_url = video_object.get("file_path")
        directory_path = os.path.join(os.environ['km_azure_home'], "video_transcribed_text", "knowledge_graph_creation")
        if not (os.path.exists(directory_path)):
            logger.info("Creating Transcribed text folder for Knowledge Graph creation")
            os.makedirs(directory_path)
        video_file_name = pathlib.Path(video_file_path).stem

        transcribed_text_file_name = os.path.join(directory_path, video_file_name + ".txt")

        extracted_tuple_list = VideoTextExtraction(video_file_name).frame_text_extraction(video_file_path,
                                                                                          image_handler)
        transcribe_model_output = self.transcribe_model.transcribe(video_file_path)
        entire_transcription_string = transcribe_model_output["text"]

        current_start = transcribe_model_output['segments'][0]['start']
        current_end = 0
        chunk_size = current_max_end = 60  # one minute
        current_text = ''
        video_text_chunk_list = []
        for i in range(len(transcribe_model_output['segments'])):
            text = transcribe_model_output['segments'][i]['text']
            current_text = current_text + text
            current_end = transcribe_model_output['segments'][i]['end']
            if current_max_end - 3 <= current_end or i == len(transcribe_model_output['segments']) - 1:
                video_text_chunk_list.append([current_text, current_start, current_end])
                current_start = current_end
                current_max_end = current_max_end + chunk_size
                current_text = ''
        transcription_chunks = []
        current_index = 0
        for i in range(len(video_text_chunk_list)):
            start = video_text_chunk_list[i][1]
            end = video_text_chunk_list[i][2]
            transcribed_text = video_text_chunk_list[i][0]
            result_string = ""
            for j in range(current_index, len(extracted_tuple_list)):
                if extracted_tuple_list[j][1] > end:
                    current_index = j
                    break
                else:
                    words = extracted_tuple_list[j][0].split()
                    if len(words) >= 2:
                        if 'ocr_image_text' == words[0] and 'ocr_image_text' == words[-1]:
                            result_string = ' '.join(words[1:-1])
                        else:
                            result_string = extracted_tuple_list[j][0]
                    else:
                        result_string = extracted_tuple_list[j][0]

            transcription_chunks.append({
                "segment_id": str(uuid.uuid4()),
                "segment_content": transcribed_text,
                "segment_metadata": {
                    "file_path": video_file_path,
                    "file_name": os.path.basename(video_file_path),
                    "segment_type": "transcript_chunk",
                    "segment_number": i + 1,
                    "start_time": start,
                    "end_time": end,
                    "displayed_text": result_string
                }
            })

        if os.path.exists(transcribed_text_file_name):
            logger.info(f"Removing Old transcribed file at path : {transcribed_text_file_name}")
            os.remove(transcribed_text_file_name)
        with open(transcribed_text_file_name, 'w') as file:
            file.write(entire_transcription_string)
            logger.info(f"Video transcribed text file created at path :  {transcribed_text_file_name}")

        return transcription_chunks

    def video_audio_to_text(self, media_path, file_type=""):
        directory_path = os.path.join(os.environ['km_azure_home'], "video_transcribed_text", "file_mode_summarization")
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
            logger.info("Creating Transcribed text folder for File Summarization")

        video_file_name = pathlib.Path(media_path).stem

        transcribed_text_file_name = os.path.join(directory_path, video_file_name + ".txt")

        transcribe_model_output = self.transcribe_model.transcribe(media_path)
        entire_transcription_string = transcribe_model_output["text"]

        if os.path.exists(transcribed_text_file_name):
            os.remove(transcribed_text_file_name)
            logger.info(f"Removing old transcribed text file {transcribed_text_file_name}")
        else:
            with open(transcribed_text_file_name, 'w') as file:
                file.write(entire_transcription_string)

                logger.info(f"Video transcribed text file created at path :  {transcribed_text_file_name}")

        return entire_transcription_string
