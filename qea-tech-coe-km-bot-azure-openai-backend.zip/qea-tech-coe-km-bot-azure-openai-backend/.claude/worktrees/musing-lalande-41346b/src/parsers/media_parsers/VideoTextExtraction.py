import shutil
from utilities.AppLogger import global_logger
import cv2
import os
from skimage.metrics import structural_similarity as compare_ssim
import re
from nltk.corpus import stopwords

logger = global_logger


class VideoTextExtraction(object):
    def __init__(self, file_name):
        # pass
        self.video_dir = os.path.join(os.environ['km_azure_home'], "OcrImageTempStorage", file_name)
        if not os.path.exists(self.video_dir):
            os.makedirs(self.video_dir)
        elif len(os.listdir(self.video_dir)) != 0:
            try:
                for file_name in os.listdir(self.video_dir):
                    # construct full file path
                    file_path = os.path.join(self.video_dir, file_name)
                    if os.path.isfile(file_path):
                        os.remove(file_path)
            except Exception as e:
                logger.error(f"Error in Video Frames Image Removal : {e}")

    def remove_common_words(self, first_string, second_string):
        stopwords_list = stopwords.words('english')


        # Split the strings into words
        first_words = re.findall(r'\b\w+\b', first_string.lower())
        second_words = re.findall(r'\b\w+\b', second_string.lower())

        answer = []
        for word in second_words:
            if word not in first_words or word in stopwords_list:
                answer.append(word)

        return ' '.join(answer)

    def frame_text_extraction(self, video_path, image_handler=None):

        # Create the output directory if it doesn't exist
        if not os.path.exists(self.video_dir):
            os.makedirs(self.video_dir)

        # Open the video file
        video_capture = cv2.VideoCapture(video_path)

        fps = int(video_capture.get(cv2.CAP_PROP_FPS))

        frame_count = 0
        actual_frame_count = 0
        timestamp_array = []
        # Read frames until the video ends
        while video_capture.isOpened():
            # Read the current frame
            ret, frame = video_capture.read()
            if not ret:
                break
            actual_frame_count += 1
            if actual_frame_count % fps == 0:
                frame_count += 1
                # Get the current timestamp
                timestamp_ms = video_capture.get(cv2.CAP_PROP_POS_MSEC)
                timestamp_sec = timestamp_ms / 1000.0
                timestamp_array.append(timestamp_sec)
                # Construct the output file path
                output_path = os.path.join(self.video_dir, f'frame_{frame_count}.jpg')
                # Save the frame as an image
                cv2.imwrite(output_path, frame)

        # Release the video capture
        video_capture.release()
        cv2.destroyAllWindows()

        extracted_text_tuple_list = []
        extracted_text = ''
        if image_handler is not None:
            extracted_text = self.ocr_video_images(image_handler, self.video_dir, 'frame_1.jpg')
        if extracted_text is None:
            extracted_text = ''
        extracted_text_tuple_list.append((extracted_text, timestamp_array[0]))
        current_frame = 1

        for frame in range(2, frame_count):
            # Load the two frames for comparison
            frame1 = cv2.imread(os.path.join(self.video_dir, f'frame_{current_frame}.jpg'), cv2.IMREAD_GRAYSCALE)
            frame2 = cv2.imread(os.path.join(self.video_dir, f'frame_{frame}.jpg'), cv2.IMREAD_GRAYSCALE)
            # Calculate the SSIM between the images
            ssim_score = compare_ssim(frame1, frame2)

            # Check if frames are exactly the same
            if ssim_score < 0.8:
                if image_handler is not None:
                    extracted_text = self.ocr_video_images(image_handler, self.video_dir, f'frame_{frame}.jpg')
                if extracted_text is None:
                    extracted_text = ''
                if extracted_text != extracted_text_tuple_list[-1][0]:
                    uncommon_extracted_text = self.remove_common_words(extracted_text_tuple_list[-1][0], extracted_text)
                    extracted_text_tuple_list.append((uncommon_extracted_text, timestamp_array[frame - 1]))
                current_frame = frame
        shutil.rmtree(self.video_dir)
        return extracted_text_tuple_list

    def ocr_video_images(self, image_handler, video_dir, image_name):
        return image_handler.ocr(video_dir, image_name)
