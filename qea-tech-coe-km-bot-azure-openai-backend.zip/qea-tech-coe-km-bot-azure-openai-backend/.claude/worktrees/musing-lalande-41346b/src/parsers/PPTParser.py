import datetime
import collections
import collections.abc
import shutil
import uuid
import pptx
import re
import os

from parsers.ParseTable import parse_table

from utilities.AppLogger import global_logger

logger = global_logger


class PPTParser():
    """
    This class handles any Power-Point Presentation File
    and extracts text from each slide in a certain format.
    In the end it returns a list structure.
    """

    def __init__(self):
        self.segment_type = "slide"
        self.ppt_dir = os.path.join(os.environ['km_azure_home'], "OcrImageTempStorage", "PPTImages")

    def parse(self, document_path, **kwargs) -> list:
        if not os.path.exists(self.ppt_dir):
            os.makedirs(self.ppt_dir)
        elif len(os.listdir(self.ppt_dir)) != 0:
            try:
                for file_name in os.listdir(self.ppt_dir):
                    # construct full file path
                    file_path = os.path.join(self.ppt_dir, file_name)
                    if os.path.isfile(file_path):
                        os.remove(file_path)
            except Exception as e:
                logger.error(f"Error PPT Image Removal : {e}")

        # image_handler = kwargs.get("image_handler")
        file_name = os.path.basename(document_path)

        ppt_slides = pptx.Presentation(document_path).slides
        content = list()
        segment_number = 1

        for slide in ppt_slides:
            content_segment = dict()
            slide_text_list = self.__extract_text_from_current_slide(slide, document_path, None)
            if slide_text_list:
                segment_id = self.__generate_id()
                content_segment.update(
                    segment_id=segment_id,
                    segment_content=" ".join(slide_text_list),
                    segment_metadata={
                        "segment_type": self.segment_type,
                        "segment_number": segment_number,
                        "file_path": document_path,
                        "file_name": file_name
                    }
                )
                content.append(content_segment)
                segment_number += 1

        shutil.rmtree(self.ppt_dir)
        return content

    def __extract_text_from_current_slide(self, slide, document_path, image_handler=None):
        slide_text_list = list()
        num = 1
        table_text_list = []
        table_exists = False;
        for shape in slide.shapes:
            shape_text, text_type = self.__extract_text_from_shape(shape, document_path, image_handler)
            if shape_text:
                if text_type == "Text":
                    slide_text_list.append(shape_text)
                elif text_type == "Table":
                    table_exists = True
                    table_text_list.append(shape_text)
                num += 1

        if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip() != "":
            notes_text = self.__filter_text_from(slide.notes_slide.notes_text_frame.text)
            slide_text_list.append(notes_text)

        if table_exists:
            slide_text_list.append("Table\n")
            for table in table_text_list:
                slide_text_list.append(table)

        return slide_text_list

    def __extract_text_from_shape(self, shape, document_path, image_handler=None):
        if shape.has_text_frame:
            return self.__filter_text_from(shape.text), "Text"
        elif shape.has_table:
            return parse_table(shape), "Table"
        else:
            return "", ""

    def __filter_text_from(self, raw_text: str):
        filtered_text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', ' ', raw_text)
        return ' '.join(filtered_text.split())

    def __generate_id(self):
        return str(uuid.uuid4())

