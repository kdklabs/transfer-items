import os
import uuid


from docx import Document
from transformers import AutoTokenizer, AutoModelForTokenClassification
from parsers.word_parser.VisionDocumentParser import TextDocumentParser

from utilities.DocumentChunker import chunk_document_texts
from utilities.WordParserUtilities import Utilities

from parsers.word_parser.WordDocumentTableParser import process_document
from utilities.utils import unique_id_generator

from typing import List, Dict


class WordParser:
    def __init__(self, model_id):
        self.file_path = ""
        self.file_name = ""
        # self.metadata_list = []
        # self.unique_ids = []
        self.model_id = model_id
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id,cache_dir=os.path.join(os.getenv('km_azure_home'), "Model"))
        self.model = AutoModelForTokenClassification.from_pretrained(self.model_id,cache_dir=os.path.join(os.getenv('km_azure_home'), "Model"))

    def set_file_name(self):
        return os.path.basename(self.file_path)

    def refresh_values(self):
        self.page_content_list = []
        self.metadata_list = []
        self.unique_ids = []

    def return_heading_count(self, doc):
        heading_count = 0
        for paragraph in doc.paragraphs:
            # Checking if the paragraph is a heading
            if paragraph.style.name.startswith('Heading'):
                heading_count += 1

        return heading_count

    def word_parser(self, file_path):
        # Insert check for absolute path and break-down into if and else
        self.file_path = file_path
        self.file_name = self.set_file_name()

        if self.file_name.endswith('.pdf'):
            pdf_parser = TextDocumentParser(self.model, self.tokenizer)
            model_parsed_df_list = pdf_parser.pdf_processor(file_path)
            model_parsed_df = pdf_parser.combine_datasets(model_parsed_df_list)
            parser_format_data = pdf_parser.df_to_parser_format(model_parsed_df, file_path)
            return parser_format_data

        elif self.file_name.endswith('.docx'):
            doc = Document(self.file_path)

        else:
            doc = Document(Utilities.convert_doc_to_docx(Utilities(), doc_path=self.file_path))

        heading_count = self.return_heading_count(doc=doc)

        if heading_count:
            # parser = WordDocumentParser()
            # x, parsed_data_list = parser.parse(self.file_path, self.file_name, None)
            table_data = process_document(file_path)

            return self.chunk_from_heading_based_parser(table_data)
        else:
            parser = TextDocumentParser(self.model, self.tokenizer)
            parsed_data_list = parser.parse(self.file_path, "document", None)
            self.remove_pdf()
            return parsed_data_list

    def initialize_model(self):
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
        self.model = AutoModelForTokenClassification.from_pretrained(self.model_id)

    def chunk_from_vision_document_parser(self, parsed_data_list: list):

        # self.refresh_values()

        page_content_list = []
        metadata_list = []
        unique_ids = []

        for dict_segment in parsed_data_list:
            chunks = chunk_document_texts(dict_segment["segment_content"])
            for chunk_content in chunks:
                chunk_content.metadata[f"Header_1"] = dict_segment["segment_metadata"]["heading"]
                chunk_content.metadata["file_name"] = self.file_name
                chunk_content.metadata["file_path"] = self.file_path
                chunk_content.metadata["page_no"] = dict_segment["segment_metadata"]["page_no"]

                page_content_list.append(chunk_content.page_content)
                metadata_list.append(chunk_content.metadata)
                unique_ids.append(unique_id_generator())

        return unique_ids, page_content_list, metadata_list

    def chunk_from_heading_based_parser(self, parsed_data: List[Dict]) -> List[Dict]:
        """
        This function parses the old parser format into a homogenous structure
        :param parsed_data: Parser output of WordDocumentParser
        :return: List of Document Segments
        """
        parsed_output = []
        segment = {}
        segment_metadata = {}
        heading_concatenation = ""
        segment_count = 0

        for i in range(len(parsed_data)):
            dict_element = parsed_data[i]
            # If the dict segment does not have paragraphs, only heading
            if 'header_content' not in dict_element:
                heading_concatenation += " " + dict_element.get('header')

            # Dict Segment has paragraph-text or 'header_content'
            else:
                segment_count += 1
                heading_concatenation += " " + dict_element.get('header')

                segment_metadata.update(file_path=self.file_path,
                                        file_name=self.file_name,
                                        heading=heading_concatenation,
                                        segment_number=segment_count,
                                        segment_type='heading')

                segment.update(segment_id=str(uuid.uuid4()),
                               segment_content=dict_element.get('header_content'),
                               segment_metadata=segment_metadata)

                parsed_output.append(segment)
                heading_concatenation = ""
                segment = {}
                segment_metadata = {}

        # If the document only consisted of headings
        if not parsed_output and heading_concatenation:
            segment_metadata.update(file_path=self.file_path,
                                    file_name=self.file_name,
                                    heading=heading_concatenation,
                                    segment_number=1,
                                    segment_type='heading')

            segment.update(segment_id=str(uuid.uuid4()),
                           segment_content=heading_concatenation,
                           segment_metadata=segment_metadata)
            parsed_output.append(segment)


        return parsed_output

    def remove_pdf(self):
        # Split the file path into directory and file
        directory, file_with_extension = os.path.split(self.file_path)

        # Split the file into name and extension
        name, extension = os.path.splitext(file_with_extension)

        # Construct the new file path with .pdf extension
        pdf_path = os.path.join(directory, name + '.pdf')

        if os.path.exists(pdf_path):
            os.remove(pdf_path)

    def chunk_from_heading_based_parser_legacy(self, parsed_data_list: list):

        page_content_list = []
        metadata_list = []
        unique_ids = []

        parsed_data_list.pop(0)

        for dict_segment in parsed_data_list:
            chunks = chunk_document_texts(dict_segment['header_content'])
            for chunk_content in chunks:
                chunk_content.page_content = dict_segment["header"] + " \n " + chunk_content.page_content
                chunk_content.metadata[f"Header_1"] = dict_segment["header"]
                chunk_content.metadata["file_name"] = self.file_name
                chunk_content.metadata["file_path"] = self.file_path

                unique_ids.append(unique_id_generator())
                page_content_list.append(chunk_content.page_content)
                metadata_list.append(chunk_content.metadata)

        return unique_ids, page_content_list, metadata_list