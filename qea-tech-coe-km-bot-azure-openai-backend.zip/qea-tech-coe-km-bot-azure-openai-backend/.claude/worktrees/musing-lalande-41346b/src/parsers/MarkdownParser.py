import os
import re
from bs4 import BeautifulSoup
from langchain.text_splitter import MarkdownHeaderTextSplitter
from markdown import markdown
from utilities.AppLogger import global_logger
from utilities.DocumentChunker import chunk_document_texts
from utilities.utils import release_file_pattern_check
from utilities.utils import unique_id_generator, find_outlier_chunk

logger = global_logger
HEADER_1 = "Header 1"


def read_md_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            md_content = file.read()
            return md_content
    except FileNotFoundError:
        logger.error(f"Error: File '{file_path}' not found.")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")


def markdown_header_split(markdown_text):
    headers_to_split_on = [("#", HEADER_1)  # ("##", "Header 2"),
                           ]
    markdown_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=headers_to_split_on)
    markdown_documents = markdown_splitter.split_text(markdown_text)
    return markdown_documents


def identify_text_format(text):
    """
    Identifies whether a given text is HTML or Markdown based on key pattern differences.

    Args:
      text: The text string to be analyzed.

    Returns:
      A string: "html" if the text is HTML, "markdown" if it's Markdown, or "unknown" if unable to determine.
    """
    # Check for Markdown indicators
    if "#" in text or "*" in text or "-" in text:
        # Check for headings, emphasis, or lists
        if re.search(r"(^#+ )|(^[*_-]+\s)", text, re.MULTILINE):
            return "markdown"

    # Check for HTML indicators
    if "<" in text and ">" in text:
        # Check for common HTML tags
        if re.search(r"(<[^/]*?>)|(/?[^>]+>)", text, re.IGNORECASE):
            return "html"

    # If no clear indicators found, default to unknown
    return "unknown"


def get_blocklist_text(html_content):
    """
    Extracts all text within `<ul class="blocklist">` tags from an HTML file.

    Args:
      filepath: The path to the HTML file.

    Returns:
      A list of strings containing the text within each blocklist section.
      :param html_content:
    """
    blocklist_text = []

    soup = BeautifulSoup(html_content, "lxml")

    # Find all ul elements with class="blocklist"
    blocklist_tags = soup.find_all("ul", class_="blockList")

    for tag in blocklist_tags:
        # Extract the text content of each list item
        text = "\n".join([str(item.text) for item in tag.find_all("li")])
        blocklist_text.append(text)

    return blocklist_text


def convert_markdown_text(markdown_text):
    """ Converts a markdown string to plaintext """
    # md -> html -> text since BeautifulSoup can extract text cleanly
    html = markdown(markdown_text)
    # remove code snippets
    # html = re.sub(r'<pre>(.*?)</pre>', ' ', html)
    # html = re.sub(r'<code>(.*?)</code >', ' ', html)
    # # extract text
    soup = BeautifulSoup(html, "html.parser")
    text = ''.join(soup.findAll(string=True))

    return text


def parsed_markdown_text_metadata(file_path):
    page_content_list = []
    metadata_list = []
    unique_ids = []
    is_matched, version, date = release_file_pattern_check(str(os.path.basename(file_path)))
    # read the md text from the md file in md format
    read_md_text = read_md_file(file_path)

    # analyze the text format
    text_format = identify_text_format(read_md_text)

    if text_format == "html":

        parsed_html_content_list = get_blocklist_text(read_md_text)
        cleaned_chunk = find_outlier_chunk(parsed_html_content_list)

        for text in cleaned_chunk:
            html_chunks = chunk_document_texts(text)

            for chunks in html_chunks:

                if is_matched:

                    document_content_release_version = f"Release Version {version}\n {chunks.page_content}"

                    page_content_list.append(document_content_release_version)
                    chunks.metadata['release_version'] = version
                    chunks.metadata['release_file'] = True
                else:
                    page_content_list.append(chunks.page_content)
                    chunks.metadata['release_file'] = False

                chunks.metadata['file_name'] = os.path.basename(file_path)
                chunks.metadata['file_path'] = file_path

                metadata_list.append(chunks.metadata)
                unique_ids.append(unique_id_generator())
        return unique_ids, page_content_list, metadata_list
    else:
        markdown_split_by_head_document = markdown_header_split(read_md_text)

        # loop through markdown_split_by_head_document and update the page content
        for document in markdown_split_by_head_document:

            if HEADER_1 in document.metadata:
                document.page_content = f"{document.metadata['Header 1']} \n {document.page_content}"

        split_parsed_data_chunks = []
        for document in range(len(markdown_split_by_head_document)):
            split_texts = chunk_document_texts(markdown_split_by_head_document[document].page_content)

            for text_index in range(len(split_texts)):
                split_texts[text_index].metadata = markdown_split_by_head_document[document].metadata

            split_parsed_data_chunks.append(split_texts)
        is_matched, version, date = release_file_pattern_check(str(os.path.basename(file_path)))

        for document_chunks in split_parsed_data_chunks:

            for document in document_chunks:

                # Check if the file is release file or not
                file_name_without_extension = os.path.splitext(os.path.basename(file_path))[0]

                if is_matched:

                    document_content_release_version = f"Release Version {version}\n {document.page_content}"

                    page_content_list.append(document_content_release_version)
                    document.metadata['release_version'] = version
                    document.metadata['release_file'] = True
                else:
                    file_name_with_document_content = f"{file_name_without_extension}\n {document.page_content}"
                    page_content_list.append(file_name_with_document_content)
                    document.metadata['release_file'] = False

                # add the  info in metadata
                document.metadata['file_name'] = os.path.basename(file_path)
                document.metadata['file_path'] = file_path

                metadata_list.append(document.metadata)

                unique_ids.append(unique_id_generator())

        return unique_ids, page_content_list, metadata_list


def parsed_markdown_text_metadata1(file_path):
    page_content_list = []
    metadata_list = []
    unique_ids = []
    # read the md text from the md file in md format
    read_md_text = read_md_file(file_path)

    # split the markdown
    markdown_split_by_head_document = markdown_header_split(read_md_text)

    # loop through markdown_split_by_head_document and update the page content
    for document in markdown_split_by_head_document:

        if HEADER_1 in document.metadata:
            document.page_content = f"{document.metadata['Header 1']} \n {document.page_content}"

    split_parsed_data_chunks = []
    for document in range(len(markdown_split_by_head_document)):
        split_texts = chunk_document_texts(markdown_split_by_head_document[document].page_content)

        for text_index in range(len(split_texts)):
            split_texts[text_index].metadata = markdown_split_by_head_document[document].metadata

        split_parsed_data_chunks.append(split_texts)
    is_matched, version, date = release_file_pattern_check(str(os.path.basename(file_path)))

    for document_chunks in split_parsed_data_chunks:

        for document in document_chunks:

            # Check if the file is release file or not

            if is_matched:

                document_content_release_version = f"Release Version {version}\n {document.page_content}"

                page_content_list.append(document_content_release_version)
                document.metadata['release_version'] = version
                document.metadata['release_file'] = True
            else:
                page_content_list.append(document.page_content)
                document.metadata['release_file'] = False

            # add the  info in metadata
            document.metadata['file_name'] = os.path.basename(file_path)
            document.metadata['file_path'] = file_path

            metadata_list.append(document.metadata)

            unique_ids.append(unique_id_generator())

    return unique_ids, page_content_list, metadata_list
