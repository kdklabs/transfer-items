import os

from langchain_openai import AzureChatOpenAI
from langchain.prompts.prompt import PromptTemplate
from langchain.chains import LLMChain
from utilities.AppLogger import global_logger


logger = global_logger


class AzureOpenAILlm:
    def __init__(self, config_dict):

        self.llm_config = config_dict

        self.azure_openai_llm = AzureChatOpenAI(azure_deployment=self.llm_config.get("deployment_name"),
                                                model_name=self.llm_config.get("model_name"),
                                                temperature=self.llm_config.get("temperature"))

        self.token_length_factor = self.llm_config.get("token_length_factor")
        self.max_total_tokens = self.llm_config.get("max_total_tokens")
        self.allowed_topics = self.llm_config.get("allowed_topics")

    async def question_answer_custom_chain(self, question, context, conversation_summary):
        template = """
        
      
        Provide an answer to the user's question or question in form of statements by considering the following factors:
        
        Allowed Topics : {allowed_topics}.
        
        1. Previous Conversation Summary: If available, consider the summary of the previous conversation for 
        context. However, be cautious that it may not always be relevant or could be empty.
        
        2. Context: Take into account any context provided by the user, but exercise judgment as context may not
        always be pertinent.
        
        3. User Question: Analyze the user's question to understand their query. Ensure that the user question is clear
         and check if it requires additional information.
        
        4. Using Model's Knowledge: Only use the Context provided and Previous Conversation Summary to form the answer.
          If the question requires more information then use your knowledge.
        
        5. No Relevant Information: If there is no relevant answer in your knowledge, please clearly state, 
        "I'm sorry, I didn't understand your question. Could you please rephrase it or provide more details so I can better assist you?"
        
        6. Please format your response in a point-wise manner separated by the <point> tag.
        
        7. Never mention or write about Previous Conversation Summary ,Context in the answer to the question.
        
        

        Previous Conversation Summary : {conversation_summary}
        Context: {context}

        Question: {question}
        Answer: 
       

        """

        prompt = PromptTemplate(input_variables=["allowed_topics", "context", "question", "conversation_summary"],
                                template=template)
        qa = LLMChain(llm=self.azure_openai_llm,
                      prompt=prompt)
        if conversation_summary is not None:
            initial_token_length = int(len(question) / self.token_length_factor) + int(
                len(template) / self.token_length_factor) + int(
                len(conversation_summary) / self.token_length_factor) + int(len(context) / self.token_length_factor)
        else:
            initial_token_length = int(len(question) / self.token_length_factor) + int(
                len(template) / self.token_length_factor) + int(len(context) / self.token_length_factor)

        logger.info(initial_token_length)
        # Check if the initial combined token length exceeds the limit
        if initial_token_length > self.max_total_tokens:
            # Calculate the maximum allowed token length for context
            max_context_token_length = self.max_total_tokens - (
                    initial_token_length - int(len(context) / self.token_length_factor))

            # Reduce the context length while keeping it above zero
            context = context[:int(max_context_token_length * self.token_length_factor)]
            logger.info("Adjusted context:", context)
        else:
            logger.info("Total token length is within the limit.")

            # Recalculate the final combined token length
        final_token_length = int(len(question) / self.token_length_factor) + int(
            len(template) / self.token_length_factor) + int(
            len(conversation_summary) / self.token_length_factor) + int(len(context) / self.token_length_factor)
        logger.info("Final combined token length:", final_token_length)

        llm_ans = qa({"allowed_topics": self.allowed_topics, "context": str(context), "question": question,
                      "conversation_summary": conversation_summary})

        return llm_ans

    async def user_bot_conversation_summary(self, chat_history):
        template = """
                    Progressively summarize the lines of conversation 
                    START EXAMPLE
                    
                    Lines of conversation:
                    
                    Human : What is Appium 
                    AI : Appium is an open-source automation tool for mobile applications, allowing cross-platform testing of Android and 
                    iOS apps.

                    Human : What is selenium
                    AI : Selenium is an open-source framework primarily used for automating web browsers, enabling the 
                    testing and automation of web applications
                    
                    New summary:
                    The human asks about Appium, and the AI explains that Appium is an open-source automation tool for mobile applications,
                    supporting cross-platform testing of Android and iOS apps. Additionally, the human inquires about Selenium, 
                    and the AI describes Selenium as an open-source framework primarily used for automating web browsers and testing web applications.
                    
                    END EXAMPLE     
                    
                   
                          
                                    
                    New lines of conversation:
                    {new_lines}
                    
                    New summary:"""

        prompt = PromptTemplate(input_variables=["new_lines"], template=template)
        summary_llm = LLMChain(llm=self.azure_openai_llm,
                               prompt=prompt)

        llm_ans = summary_llm({"new_lines": str(chat_history)})
        return llm_ans

    async def custom_llm_release_chain(self, question: str):

        template = """
        Given a question check        
        If the question ask about changes,release information or any information about specific version of software's or the subject 
        of question then check 
        If it has release number in the question 
        If release number found return list [True,version number] only 
        If release number not found return list [True,None] only 
        If the question doesn't ask about release or any changes return list [False,None] only
        
        
        Dont send any other information 
        
        Example 1 :
        Question : "How to use iterators in Java9"
        True,9
        
        Example 2 :
        Question : "Whats are the changes done in latest version of python "
        True,None
        
        Example 3 :
        Question : "List down the changes in Framework version 9.0.2"
        True,9.0.2
        
        Example 1 :
        Question : "Can you tell me what features changed in 2.1 of Gauva framework"
        True, 2.1
        Question: {question}
        
         

                """
        prompt = PromptTemplate(input_variables=["question"], template=template)
        qa = LLMChain(llm=self.azure_openai_llm,
                      prompt=prompt)

        llm_ans = qa({"question": question})
        version_info_details = llm_ans['text'].split(",")

        if version_info_details[0] == "True":
            return version_info_details[1]
        else:
            return None

    async def question_rewrite_chain(self, previous_conversation: str):

        template = """
        Given the conversation, perform the following task:
        Task 1 : Try to identify if the Human has given subject in previous conversation and is asking 
                question related to the same subject. 
                If yes then rewrite the question with subject and return it else return the original question.
                Only return question and no other information or comment
                
        Example 1: 
            Prev Conversation:
                Human : What is selenium?
                AI : Selenium is an open source umbrella project for a range of tools and libraries aimed at supporting browser automation.
                
                Human : Which language can be used with it?
                Question : Which language can be used with selenium?
        End of Example 1
        
        Example 2: 
            Prev Conversation:
                Human : What framework can be used for browser testing ?
                AI : Selenium is one of the most widely used browser automation frameworks. 
                
                Human : Which language does it support?
                Question : Which language does selenium support?
        End of Example 2
        
         Example 3: 
            Prev Conversation:
                Human : What is selenium?
                AI : Selenium is an open source umbrella project for a range of tools and libraries aimed at supporting browser automation.
                
                Human : How to use constructor in Java?
                Question : How to use constructor in Java?
        End of Example 3
        
        Example 4: 
            Prev Conversation:
                Human : How to use constructor in Java?
                AI : In Java, a constructor is a block of codes similar to the method. It is called when an instance of the class is created
                
                Human : I am getting IllegalArgumentException
                Question : I am getting IllegalArgumentException
        End of Example 4
        
        Previous Conversation :{previous_conversation}
        Question : 
        
        """
        prompt = PromptTemplate(input_variables=["previous_conversation"], template=template)
        qa = LLMChain(llm=self.azure_openai_llm,
                      prompt=prompt)

        llm_ans = qa({"previous_conversation": previous_conversation})
        llm_generated_question = llm_ans['text']

        return llm_generated_question

    def check_question_related_to_allowed_topics(self, question: str):

        template = """
        If question related to allowed topics return True else False.
        Allowed Topics : {allowed_topics} 
        
        
        Question : {question}
        """

        prompt = PromptTemplate(input_variables=["allowed_topics", "question"], template=template)
        qa = LLMChain(llm=self.azure_openai_llm,
                      prompt=prompt)

        llm_ans = qa({"allowed_topics": self.allowed_topics, "question": question})
        llm_generated_question = llm_ans['text']

        return llm_generated_question

    async def check_bot_answer_the_question_or_not(self, question, answer):

        template = """

        Given the question and answer try to identify 
        whether the bot was able to answer it or not.

        Return True when bot answer the question.
        Return False when bot didn't answer the question.


        Example 1: 
        Question:  Who is MS Dhoni?
        Answer: "I'm sorry, I didn't understand your question. Could you please rephrase it or provide more details so I can better assist you?"
        False 

        Question : What is Python?
        Answer : Python is general purpose programming language, which is used in Web Development and Data Science.
        True


        Question: {question}

        Answer: {answer}

        """

        prompt = PromptTemplate(input_variables=["question", "answer"], template=template)
        qa = LLMChain(llm=self.azure_openai_llm,
                      prompt=prompt)

        llm_ans = qa({"question": question, "answer": answer})
        words_to_check = ["didn't", "sorry", "rephrase", "understand", "question", "assist"]
        if llm_ans['text'] == "True":
            return True
        elif llm_ans['text'] == "False":
            sentence = answer.lower()

            # Count the number of words from the list present in the sentence
            count = sum(1 for word in words_to_check if word in sentence)

            # Return True if more than one word is present, else return False
            if count > 1:
                return False
            else:
                return True

    def check_cache_answer_is_right_or_not(self, cached_user_question: str, cached_bot_answer: str,
                                           current_user_question: str):

        template = """
           Return True or False based on the following instructions :
           1. You will be given the cached_user_question , cached_bot_answer and current_user_question 
           2. If cached_bot_answer is the correct answer for the current_user_question then return True.
           3. If cached_bot_answer is the wrong answer for the current_user_question then return False.
            

        
           cached_user_question : {cached_user_question}
           cached_bot_answer : {cached_bot_answer}
           current_user_question:{current_user_question}
           
           """

        prompt = PromptTemplate(input_variables=["cached_user_question", "cached_bot_answer", "current_user_question"],
                                template=template)

        qa = LLMChain(llm=self.azure_openai_llm,
                      prompt=prompt)

        llm_ans = qa({"cached_user_question": cached_user_question, "cached_bot_answer": cached_bot_answer,
                      "current_user_question": current_user_question})
        if llm_ans['text'] == "True":
            return True
        elif llm_ans['text'] == "False":
            return False
