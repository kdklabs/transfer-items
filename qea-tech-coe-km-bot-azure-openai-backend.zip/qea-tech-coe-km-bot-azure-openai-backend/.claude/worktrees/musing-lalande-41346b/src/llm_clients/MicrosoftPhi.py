from llama_cpp import Llama


class Phi3:
    def __init__(self, model_path,model_config):

        self.model_config = model_config
        print(self.model_config )
        self.phi3_llm = Llama(

            model_path=model_path,
            n_ctx=self.model_config['n_ctx'], #4096,
            n_threads=self.model_config['n_threads'], #8,  # The number of CPU threads to use, tailor to your system and the resulting performance

        )

    async def question_answer_custom_chain(self, question, context):
        prompt = f""" 
         Answer the following question using the knowledge provided in the context , dont write any 
         other information based on your knowledge and also that you are using your context information to form the answer
         question :{question}
         context : {context}
        
        """

        output = self.phi3_llm(
            f"<|user|>\n{prompt}<|end|>\n<|assistant|>",
            max_tokens=self.model_config['max_tokens'], #2000,  # Generate up to 256 tokens
            stop=["<|end|>"],
            temperature=self.model_config['temperature'], #0.4,
            echo=self.model_config['echo'], #False,

        )

        return output['choices'][0]['text']


# Phi3(r"C:\Users\JAISGHFST\Documents\qea-tech-coe-km-bot-azure-openai_home\Model\llamamodel\Phi-3-mini-4k-instruct-q4.gguf")
