# qea-tech-coe-km-bot-azure-openai
KM bot version with Azure Open AI 


# Project Setup Instructions

1. Create a new virtual environment
2. Install the required poetry version using the following command:
```bash
pip install -r requirements.txt
```
3. Open the command prompt and run the following command:
```bash
poetry install
```
This will install the packages in the python virtual environment, 
using the **poetry.lock** file.

4. To install or remove any  package add/delete the package details in pyproject.toml file and run the following command:
```bash
poetry update 
```
This will update the **poetry.lock** file with the new package details and install the new package in the virtual environment.

5. Other way to add new package Run the following command to install new packages:
```bash
poetry add <package-name>
```
6. Run the following command to remove a package:
```bash
poetry remove <package-name>
```

